package br.com.iantzen.tempo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Insets;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends Activity {
    private WebView webView;
    private MonitorBridge bridge;
    private static final String LOCAL_HOST = "appassets.androidplatform.net";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,36,91));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,37,86));
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        // Use explicit insets so no content or buttons are hidden by system bars.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom,ime.bottom));
                return insets;
            });
        }
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        bridge = new MonitorBridge(this,webView);
        webView.addJavascriptInterface(bridge,"TEMPO_NATIVE");
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        WebView.setWebContentsDebuggingEnabled(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClientCompat() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url=request.getUrl();
                if (LOCAL_HOST.equals(url.getHost()) && "https".equals(url.getScheme())) return false;
                openExternal(url);
                return true;
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private void openExternal(Uri uri) {
        String scheme=uri.getScheme();
        if(scheme==null)return;
        if (!scheme.equals("https") && !scheme.equals("tel"))return;
        try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); }
        catch (Exception ignored) { }
    }

    @Override public void onBackPressed() {
        if (webView!=null) webView.evaluateJavascript("window.TEMPOBack && window.TEMPOBack()",null);
        else super.onBackPressed();
    }

    @Override protected void onDestroy(){if(bridge!=null){bridge.shutdown();bridge=null;}if(webView!=null){webView.destroy();webView=null;}super.onDestroy();}
}
