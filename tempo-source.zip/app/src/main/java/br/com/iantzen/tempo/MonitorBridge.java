package br.com.iantzen.tempo;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Consultas HTTPS nativas, isoladas do WebView e sem dependência de CORS. */
public final class MonitorBridge {
    private static final String UA = "TEMPO-Sapucaia-Android/0.2";
    private final Activity activity;
    private final WebView web;
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    public MonitorBridge(Activity activity, WebView web) {this.activity=activity;this.web=web;}
    @JavascriptInterface public void fetchData(String source) {
        if (!source.equals("cemaden") && !source.equals("estado") && !source.equals("ana") && !source.equals("inmet")) return;
        network.submit(() -> {
            JSONObject result;
            try {
                if (source.equals("cemaden")) result=cemaden();
                else if (source.equals("estado")) result=estado();
                else if (source.equals("ana")) result=ana();
                else result=inmet();
            } catch(Exception e) {
                result = new JSONObject();
                try {result.put("ok", false);result.put("error", "Fonte indisponível");result.put("fetchedAt", System.currentTimeMillis());}catch(Exception ignored){}
            }
            final String js = "window.TEMPO_OnNativeData(" + JSONObject.quote(source) + "," + JSONObject.quote(result.toString()) + ")";
            activity.runOnUiThread(() -> web.evaluateJavascript(js, null));
        });
    }
    public void shutdown() {network.shutdownNow();}
    private static String request(String target,String method,String body) throws Exception {
        HttpURLConnection con=(HttpURLConnection)new URL(target).openConnection();
        con.setRequestMethod(method);con.setConnectTimeout(12000);con.setReadTimeout(14000);
        con.setRequestProperty("User-Agent",UA);con.setRequestProperty("Accept","application/json,text/xml,application/xml,*/*");
        if(body!=null){con.setRequestProperty("Content-Type","application/json");con.setDoOutput(true);
            try(OutputStream out=con.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}}
        try {
            int status=con.getResponseCode();if(status < 200 || status > 299)throw new Exception("HTTP " + status);
            try (InputStream in=con.getInputStream(); BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
                StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null){sb.append(line).append('\n');if(sb.length()>8000000)throw new Exception("Excesso de dados");}return sb.toString();
            }
        } finally {con.disconnect();}
    }
    private static JSONObject result() throws Exception {JSONObject r=new JSONObject();r.put("ok",true);r.put("fetchedAt",System.currentTimeMillis());return r;}
    private static Object value(JSONObject o,String... path){Object p=o;for(String s:path){if(!(p instanceof JSONObject))return JSONObject.NULL;p=((JSONObject)p).opt(s);if(p==null)return JSONObject.NULL;}return p;}
    private static Object val(JSONObject o,String... path){String[] p=java.util.Arrays.copyOf(path,path.length+1);p[path.length]="value";return value(o,p);}
    private static double number(Object o){if(o instanceof Number)return ((Number)o).doubleValue();try{return Double.parseDouble(String.valueOf(o).replace(',','.'));}catch(Exception e){return Double.NaN;}}
    private static void putNumber(JSONObject obj,String field,Object o)throws Exception {double d=number(o);obj.put(field,Double.isFinite(d)?d:JSONObject.NULL);}
    private String loadQuery() throws Exception {try(InputStream in=activity.getAssets().open("tags-data.graphql")){StringBuilder sb=new StringBuilder();BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));String line;while((line=r.readLine())!=null)sb.append(line).append('\n');return sb.toString();}}
    private JSONObject estado()throws Exception {
        JSONObject post=new JSONObject().put("operationName","Tags_data").put("query",loadQuery());
        JSONObject response=new JSONObject(request("https://redehidrometeorologica.defesacivil.rs.gov.br/graphql","POST",post.toString()));
        if(response.has("errors"))throw new Exception("API GraphQL não autorizada");
        JSONObject root=response.optJSONObject("data");JSONObject tags=root==null?null:root.optJSONObject("tags_data");
        JSONArray all=tags==null?null:tags.optJSONArray("qualle_meteorologia");if(all==null)throw new Exception("Sem estações");
        JSONArray stations=new JSONArray();
        for(int i=0;i<all.length();i++){
            JSONObject s=all.optJSONObject(i);if(s==null)continue;
            JSONObject name=s.optJSONObject("name"),data=s.optJSONObject("data"),pos=s.optJSONObject("position");if(data==null)continue;
            String nm=(name==null?"":(name.optString("general")+" "+name.optString("local"))).trim();
            String rioNome=String.valueOf(val(data,"rio","rio_nome"));
            // Estação Esteio identificada no TEMPO original (DCRS-00119), e outras da bacia do Sinos.
            boolean isEsteio="DCRS-00119".equals(s.optString("codigo"));
            boolean isSinos=pos!=null && pos.optString("bacia","").toLowerCase(Locale.ROOT).contains("sinos");
            boolean nearby=nm.toLowerCase(Locale.ROOT).matches(".*(sapucaia|esteio|são leopoldo|sao leopoldo|canoas|novo hamburgo).*" );
            if(!isEsteio && !isSinos && !nearby)continue;
            JSONObject e=new JSONObject();e.put("codigo",s.optString("codigo"));e.put("nome",nm.isEmpty()?s.optString("codigo"):nm);
            e.put("timestamp",s.optString("timestamp"));e.put("bacia",pos==null?"":pos.optString("bacia"));
            e.put("manutencao",Boolean.TRUE.equals(val(s,"resource","estacao","estado","manutencao")));
            putNumber(e,"temperatura",val(data,"temperatura","atual"));putNumber(e,"umidade",val(data,"umidade","atual"));
            putNumber(e,"pressao",val(data,"pressaoatmos","atual"));putNumber(e,"ventoMedio",val(data,"vento","velocidade_media"));
            putNumber(e,"ventoRajada",val(data,"vento","velocidade_maxima"));putNumber(e,"ventoDirecao",val(data,"vento","direcao"));
            putNumber(e,"chuva1",val(data,"chuva","acumulado","h001"));putNumber(e,"chuva6",val(data,"chuva","acumulado","h006"));
            putNumber(e,"chuva24",val(data,"chuva","acumulado","h024"));
            putNumber(e,"rioNivel",val(data,"rio","rio_nivel"));putNumber(e,"rioTendencia",val(data,"rio","rio_nivel_tendencia"));
            e.put("rioNome",rioNome.equals("null")?"":rioNome);
            putNumber(e,"rioStatus",val(data,"rio","rio_alarmes","inundacao","status"));
            e.put("rioAlarmesAtivo",val(data,"rio","rio_alarmes","inundacao","ativo"));
            e.put("homologadoChuva",val(data,"chuva","homologacao","relacao","valido"));
            e.put("homologadoRio",val(data,"rio","homologacao","relacao","valido"));
            stations.put(e);
        }
        JSONObject out=result();out.put("stations",stations);out.put("nextUpdate",tags.optString("proximaAtualizacaoEm"));
        return out;
    }
    private JSONObject cemaden()throws Exception {
        // Estação configurada no TEMPO web: ID 4331 — G2-Colonial / Sapucaia do Sul.
        JSONObject j=new JSONObject(request("https://mapservices.cemaden.gov.br/MapaInterativoWS/resources/horario/4331/720","GET",null));
        JSONArray hours=j.optJSONArray("horarios"),dates=j.optJSONArray("datas"), rows=j.optJSONArray("acumulados");
        if(hours==null||dates==null||rows==null)throw new Exception("Resposta sem horários");
        // Não remova lacunas: uma janela incompleta não pode parecer chuva zero.
        ArrayList<Double> samples=new ArrayList<>();int missing=0;
        for(int d=0;d<rows.length();d++){
            JSONArray row=rows.optJSONArray(d);if(row==null)continue;
            for(int h=0;h<hours.length();h++){
                Object o=h<row.length()?row.opt(h):null;double mm=number(o);
                if(!Double.isFinite(mm)||mm<0){samples.add(Double.NaN);missing++;}
                else samples.add(mm);
            }
        }
        if(samples.isEmpty())throw new Exception("Sem períodos retornados");
        int n=samples.size();double h1=samples.get(n-1);
        double h6=rainWindow(samples,6),h12=rainWindow(samples,12),h24=rainWindow(samples,24);
        JSONObject st=j.optJSONObject("estacao");JSONObject out=result();out.put("stationId",4331);
        out.put("station",st==null?"G2-Colonial":st.optString("nome","G2-Colonial"));
        putNumber(out,"h1",h1);putNumber(out,"h6",h6);putNumber(out,"h12",h12);putNumber(out,"h24",h24);out.put("missingSlots",missing);
        out.put("readingAt",dates.optString(dates.length()-1)+" "+hours.optString(hours.length()-1)+" UTC");
        out.put("source","CEMADEN — dados observados");return out;
    }
    private static double rainWindow(ArrayList<Double> list,int count){
        if(list.size()<count)return Double.NaN;
        double sum=0;
        for(int i=list.size()-count;i<list.size();i++){
            double v=list.get(i);if(!Double.isFinite(v))return Double.NaN;sum+=v;
        }
        return sum;
    }
    private static String dates(Date d){SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy",Locale.ROOT);df.setTimeZone(TimeZone.getTimeZone("America/Sao_Paulo"));return df.format(d);}
    private JSONObject ana()throws Exception {
        // ANA estação São Leopoldo 87382000, conforme configuração existente no TEMPO.
        long now=System.currentTimeMillis();String from=dates(new Date(now-3L*86400000)),to=dates(new Date(now));
        String xml=request("https://telemetriaws1.ana.gov.br/ServiceANA.asmx/DadosHidrometeorologicos?codEstacao=87382000&dataInicio="+from+"&dataFim="+to,"GET",null);
        Matcher m=Pattern.compile("<DataHora>([^<]*)</DataHora>\\s*(?:<Vazao>([^<]*)</Vazao>)?\\s*(?:<Nivel>([^<]*)</Nivel>)?",Pattern.CASE_INSENSITIVE).matcher(xml);
        ArrayList<JSONObject> rows=new ArrayList<>();
        while(m.find()){
            String data=m.group(1).trim();double level=number(m.group(3));double flow=number(m.group(2));
            if(!Double.isFinite(level)&&!Double.isFinite(flow))continue;
            JSONObject item=new JSONObject();item.put("time",data);putNumber(item,"level",Double.isFinite(level)?level/100:JSONObject.NULL);
            putNumber(item,"flow",Double.isFinite(flow)?flow:JSONObject.NULL);rows.add(item);
        }
        if(rows.isEmpty())throw new Exception("ANA sem dados");
        rows.sort(Comparator.comparing(o->o.optString("time")));
        JSONObject last=rows.get(rows.size()-1);JSONObject out=result();out.put("station","São Leopoldo");out.put("stationCode","87382000");
        out.put("readingAt",last.optString("time")+" (horário de Brasília)");
        out.put("levelM",last.opt("level"));out.put("flowM3s",last.opt("flow"));
        JSONArray series=new JSONArray();for(int i=Math.max(0,rows.size()-30);i<rows.size();i++)series.put(rows.get(i));out.put("series",series);
        out.put("source","ANA — Rio dos Sinos, régua de São Leopoldo");return out;
    }
    private JSONObject inmet()throws Exception {
        JSONObject root=new JSONObject(request("https://apiprevmet3.inmet.gov.br/avisos/ativos","GET",null));
        JSONArray outAlerts=new JSONArray();for(String bucket:new String[]{"hoje","futuro"}){
            JSONArray arr=root.optJSONArray(bucket);if(arr==null)continue;
            for(int i=0;i<arr.length();i++){JSONObject a=arr.optJSONObject(i);if(a==null)continue;
                String codes=a.optString("geocodes","");if(!java.util.Arrays.asList(codes.split(",")).contains("4320008"))continue;
                JSONObject row=new JSONObject();row.put("titulo",a.optString("descricao","Aviso meteorológico"));
                row.put("severidade",a.optString("severidade",""));row.put("inicio",a.optString("inicio",""));
                row.put("fim",a.optString("fim",""));row.put("quando",bucket);outAlerts.put(row);
            }
        }
        JSONObject out=result();out.put("alerts",outAlerts);out.put("source","INMET — avisos ativos para Sapucaia do Sul (IBGE 4320008)");return out;
    }
}
