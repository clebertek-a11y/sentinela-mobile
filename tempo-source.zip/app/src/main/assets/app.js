'use strict';
// TEMPO Android • Interface local. Dados ao vivo: Open-Meteo (previsões/modelo, não sensor).
// Fontes oficiais: navegação ao site oficial no navegador externo do Android.
const $ = sel => document.querySelector(sel);
const API = 'https://api.open-meteo.com/v1/forecast?latitude=-29.8333&longitude=-51.1500&timezone=America%2FSao_Paulo&current=temperature_2m%2Capparent_temperature%2Cweather_code%2Cwind_speed_10m%2Cwind_direction_10m%2Cis_day&hourly=temperature_2m%2Cweather_code%2Cprecipitation&daily=temperature_2m_max%2Ctemperature_2m_min%2Cweather_code&past_days=1&forecast_days=7';
const CONFIG = {weatherTTL: 15*60*1000, cacheKey: 'tempo_v1_forecast', page: 'inicio'};
let weather = null;
let page = 'inicio';
const demo = new URLSearchParams(location.search).has('demo');
function icon(name){return `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;}
function str(t){return String(t||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(n, decimals=0){return Number.isFinite(Number(n)) ? Number(n).toLocaleString('pt-BR',{minimumFractionDigits:decimals,maximumFractionDigits:decimals}) : '--';}
function codeLabel(code){if(code===0)return 'Céu limpo';if([1,2].includes(code))return 'Parcialmente nublado';if(code===3)return 'Nublado';if([45,48].includes(code))return 'Neblina';if([51,53,55,56,57].includes(code))return 'Garoa';if([61,63,65,66,67,80,81,82].includes(code))return 'Chuva';if([71,73,75,77,85,86].includes(code))return 'Precipitação';if([95,96,99].includes(code))return 'Trovoadas';return 'Condição variável';}
function codeEmoji(code,isDay=true){if(code===0)return isDay?'☀️':'🌙';if([1,2].includes(code))return isDay?'⛅':'☁️';if([3,45,48].includes(code))return '☁️';if([51,53,55,56,57,61,63,65,66,67,80,81,82].includes(code))return '🌧️';if([71,73,75,77,85,86].includes(code))return '🌨️';if([95,96,99].includes(code))return '⛈️';return '🌤️';}
function dirName(deg){if(!Number.isFinite(Number(deg)))return '--';return ['N','NE','L','SE','S','SO','O','NO'][Math.round(Number(deg)/45)%8];}
function setConnection(kind,msg){const el=$('#connection-status');el.className='data-note '+kind;el.querySelector('span:last-child').textContent=msg;}
function goto(target){if(['radar','rio','chuvas','vento','sensores'].includes(target)){renderDetail(target);target='detail';}
const current=['inicio','monitorar','alertas','servicos','detail'].includes(target)?target:'inicio';page=current;document.querySelectorAll('.page').forEach(el=>el.classList.toggle('active',el.id==='pg-'+current));document.querySelectorAll('.nav-item').forEach(el=>el.classList.toggle('active',el.dataset.go===(current==='detail'?'monitorar':current)));$('.main').scrollTop=0;}
function renderDetail(which){
 window.detailTopic=which;
 const details={
 radar:{title:'Radar meteorológico',subtitle:'Monitoramento da precipitação na região metropolitana de Porto Alegre.',body:'As imagens e suas escalas de refletividade são disponibilizadas pela Defesa Civil do Rio Grande do Sul. Para não apresentar mapas desatualizados, o radar será consultado diretamente no serviço oficial.',url:'https://www.defesacivil.rs.gov.br/monitoramento-radar-meteorologico',cta:'Abrir radar oficial da Defesa Civil RS',source:'Fonte: Defesa Civil do Rio Grande do Sul.'},
 rio:{title:'Rio dos Sinos',subtitle:'Consulta hidrológica e acompanhamento do nível do rio.',body:'A medição do nível do Rio dos Sinos ainda não está integrada a esta versão. Abra o painel TEMPO existente para consultar as informações e a origem dos dados. A ausência de medição não indica normalidade.',url:'https://temposapucaia.lovable.app/',cta:'Abrir monitoramento do rio',source:'Disponibilidade e horário dependem dos sensores e do painel de origem.'},
 chuvas:{title:'Chuvas e pluviômetros',subtitle:'Previsão de chuva e monitoramento de estações.',body:'O valor de chuva exibido na página inicial é uma estimativa do modelo Open-Meteo, não uma leitura de pluviômetro. Para dados medidos por estações, utilize o painel TEMPO atual e confira a fonte e o horário.',url:'https://temposapucaia.lovable.app/',cta:'Consultar pluviômetros no TEMPO web',source:'Fonte da previsão: Open-Meteo. Dados medidos: verificar fonte no painel web.'},
 vento:{title:'Vento em Sapucaia do Sul',subtitle:'Condições meteorológicas estimadas para a região.',body:'A velocidade e a direção exibidas nesta primeira versão vêm da Open-Meteo e representam condições modeladas. Não são medições de uma estação municipal.',url:'https://temposapucaia.lovable.app/',cta:'Ver sensores no painel existente',source:'Fonte: Open-Meteo / TEMPO web.'},
 sensores:{title:'Sensores e estações',subtitle:'Status das estações e dos dados municipais.',body:'A integração automática com as estações municipais está prevista para uma próxima etapa. Até lá, consulte o sistema existente e verifique se o sensor está operacional antes de usar seus dados em decisões.',url:'https://temposapucaia.lovable.app/',cta:'Abrir painel de sensores',source:'Sensor indisponível ou sem atualização não significa ausência de risco.'}
 };
 const d=details[which];if(!d)return;
 const metric=(which==='vento'&&weather&&Number.isFinite(Number(weather.current.wind_speed_10m)))?`<div class="metric">${fmt(weather.current.wind_speed_10m)} km/h</div><p>Direção: ${dirName(weather.current.wind_direction_10m)} · Estimativa</p>`:'';
 $('#detail-content').innerHTML=`<div class="detail-hero"><h1>${d.title}</h1><p>${d.subtitle}</p></div>${renderLiveDetail(which)||`<div class="white-card detail-data">${metric}<p>${d.body}</p></div>`}<a class="external-action" href="${d.url}">${icon('external')}${d.cta}</a><p class="source-caption">${d.source}</p>`;
}
function weatherDataToUI(data, cached=false){
 if(!data || !data.current || !data.hourly || !data.daily)throw Error('Resposta meteorológica incompleta');
 weather=data;
 const c=data.current, daily=data.daily, h=data.hourly, localTime=String(c.time||'');
 $('#temp').textContent=fmt(c.temperature_2m)+'°C';
 $('#weather-summary').textContent=codeLabel(c.weather_code);
 $('#weather-glyph').textContent=codeEmoji(c.weather_code,c.is_day!==0);
 $('#feels').textContent='Sensação: '+fmt(c.apparent_temperature)+'°C';
 const di=(daily.time||[]).findIndex(t=>t===localTime.slice(0,10));const diSafe=di>=0?di:0;
 $('#hi-lo').textContent='Máx. '+fmt(daily.temperature_2m_max[diSafe])+'° · Mín. '+fmt(daily.temperature_2m_min[diSafe])+'°';
 $('#weather-updated').textContent=`Fonte: Open-Meteo · referência ${localTime.slice(11,16)||'--:--'}`;
 const idx=Math.max(0,(h.time||[]).findIndex(t=>t.slice(0,13)===localTime.slice(0,13)));
 const hours=[];for(let i=idx;i<Math.min(idx+10,h.time.length);i++){
  const temp=Number(h.temperature_2m[i]),code=Number(h.weather_code[i]);hours.push(`<div class="hour-item ${i===idx?'now':''}"><b>${i===idx?'Agora':str(h.time[i].slice(11,16))}</b><span class="emoji">${codeEmoji(code)}</span><strong>${fmt(temp)}°</strong></div>`);
 }
 $('#hourly').innerHTML=hours.join('')||'<div class="hour-placeholder">Previsão indisponível</div>';
 const names=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];let days=[];
 for(let i=Math.max(0,diSafe);i<Math.min((daily.time||[]).length,diSafe+7);i++){
  const dat=new Date(daily.time[i]+'T12:00:00');days.push(`<div class="day-item"><b>${i===diSafe?'Hoje':names[dat.getDay()]}</b><span class="emoji">${codeEmoji(daily.weather_code[i])}</span><strong><span class="max">${fmt(daily.temperature_2m_max[i])}°</span> <span class="min">${fmt(daily.temperature_2m_min[i])}°</span></strong></div>`);
 }
 $('#daily').innerHTML=days.join('')||'<div class="hour-placeholder">Previsão indisponível</div>';
 const sum=(h.precipitation||[]).slice(Math.max(0,idx-23),idx+1).reduce((a,b)=>a+(Number(b)||0),0);
 $('#rain24').textContent=fmt(sum,1)+' mm';
 $('#wind-value').textContent=fmt(c.wind_speed_10m)+' km/h';
 $('#wind-dir').textContent='Direção '+dirName(c.wind_direction_10m)+' · estimativa';
 setConnection(cached?'cached':'online',cached?'Últimos dados salvos — confirme o horário antes de utilizar.':'Previsão atualizada. Os sensores têm fontes independentes.');
}
async function updateWeather(manual=false){
 if(!navigator.onLine){const saved=localStorage.getItem(CONFIG.cacheKey);if(saved){try{weatherDataToUI(JSON.parse(saved).data,true);return;}catch{}}setConnection('error','Sem conexão. Nenhuma previsão salva disponível.');return;}
 if(!manual){const saved=localStorage.getItem(CONFIG.cacheKey);if(saved){try{const item=JSON.parse(saved);weatherDataToUI(item.data,Date.now()-item.ts>CONFIG.weatherTTL);if(Date.now()-item.ts<CONFIG.weatherTTL)return;}catch{}}}
 setConnection('','Consultando previsão Open-Meteo...');
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
 try{const response=await fetch(API,{signal:controller.signal,cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);const data=await response.json();weatherDataToUI(data);try{localStorage.setItem(CONFIG.cacheKey,JSON.stringify({data,ts:Date.now()}));}catch{}}
 catch(e){const saved=localStorage.getItem(CONFIG.cacheKey);if(saved){try{weatherDataToUI(JSON.parse(saved).data,true);return;}catch{}}setConnection('error','Previsão indisponível. Consulte novamente mais tarde.');}
 finally{clearTimeout(timer);}
}
function displayDemo(){
 // Somente para screenshot de apresentação, ativado por ?demo=1; NUNCA é usado pelo APK.
 const hourlyTime=['2026-11-20T06:00','2026-11-20T07:00','2026-11-20T08:00','2026-11-20T09:00','2026-11-20T10:00','2026-11-20T11:00','2026-11-20T12:00','2026-11-20T13:00','2026-11-20T14:00','2026-11-20T15:00','2026-11-20T16:00'];
 const ds=['2026-11-20','2026-11-21','2026-11-22','2026-11-23','2026-11-24','2026-11-25','2026-11-26'];
 weatherDataToUI({current:{time:'2026-11-20T06:00',temperature_2m:24,apparent_temperature:25,weather_code:2,is_day:1,wind_speed_10m:14,wind_direction_10m:45},hourly:{time:hourlyTime,temperature_2m:[24,25,26,27,27,28,28,27,26,25,24],weather_code:[2,2,2,1,1,2,3,61,61,3,2],precipitation:[0,0,0,0,.1,.2,.1,1,1.5,0,0]},daily:{time:ds,temperature_2m_max:[28,29,27,26,26,27,29],temperature_2m_min:[18,19,19,18,17,18,19],weather_code:[2,1,61,61,3,2,0]}});
 setConnection('','PRÉVIA DE DEMONSTRAÇÃO: valores fictícios, sem uso operacional.');
}
// CAMADA DE FONTES — coleta HTTPS nativa (sem CORS) e preservação de origem/horário.
const SOURCE_LABELS={cemaden:'CEMADEN · G2-Colonial',estado:'Defesa Civil RS · Esteio e bacia do Sinos',ana:'ANA · São Leopoldo (Rio dos Sinos)',inmet:'INMET · Avisos para Sapucaia'};
const SOURCE_TTL={cemaden:5*60*1000,estado:5*60*1000,ana:2*60*1000,inmet:10*60*1000};
const sources={};
const sourcePending={};
function msFromReading(str){
 const s=String(str||'');
 let m=s.match(/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})/);
 if(m){let utc=/UTC/.test(s);return Date.parse(`${m[3]}-${m[2]}-${m[1]}T${m[4]}:${m[5]}:00${utc?'Z':'-03:00'}`);}
 if(/^\d{4}-\d{2}-\d{2}T/.test(s))return Date.parse(s.replace(/Z?$/,'').replace(/(\.\d{3})?$/,'')+'-03:00');
 return NaN;
}
function freshness(kind,obj){
 if(!obj || !obj.ok)return {level:'off',label:'Indisponível'};
 if(obj.cached)return {level:'saved',label:'Última leitura salva'};
 if(kind==='cemaden'){
   const age=Date.now()-msFromReading(obj.readingAt);
   if(!Number.isFinite(age)||age<0||age>45*60*1000)return {level:'saved',label:'Verificar horário'};
 }
 if(kind==='ana'){
   const age=Date.now()-msFromReading(obj.readingAt);
   if(!Number.isFinite(age)||age<0||age>3*60*60*1000)return {level:'saved',label:'Leitura antiga'};
 }
 if(kind==='estado'){
   const e=stateEsteio(obj);let age=e?Date.now()-msFromReading(e.timestamp):NaN;
   if(!Number.isFinite(age)||age<0||age>35*60*1000)return {level:'saved',label:'Verificar leitura'};
 }
 return {level:'on',label:'Consultado'};
}
function stateEsteio(obj){return (obj?.stations||[]).find(s=>s.codigo==='DCRS-00119')||null;}
function numv(v,d=1,suffix=''){return v==null||!Number.isFinite(Number(v))?'--':Number(v).toLocaleString('pt-BR',{minimumFractionDigits:d,maximumFractionDigits:d})+suffix;}
function fmtReading(s){const d=msFromReading(s);return Number.isFinite(d)?new Date(d).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'America/Sao_Paulo'}):String(s||'Horário não informado');}
function metric(label,value,foot=''){return `<div class="metric-mini"><label>${str(label)}</label><strong>${str(value)}</strong>${foot?`<small>${str(foot)}</small>`:''}</div>`;}
function saveSource(kind,obj){try{if(obj.ok)localStorage.setItem('tempo_sensor_'+kind,JSON.stringify({savedAt:Date.now(),data:obj}));}catch{}}
function loadSource(kind){try{let x=JSON.parse(localStorage.getItem('tempo_sensor_'+kind)||'null');if(x&&x.data)return {...x.data,cached:true};}catch{}return null;}
window.TEMPO_OnNativeData=(kind,json)=>{
 if(!(kind in SOURCE_LABELS))return;
 sourcePending[kind]=false;
 let data;try{data=JSON.parse(json);}catch{data={ok:false};}
 if(data.ok){sources[kind]=data;saveSource(kind,data);}
 else sources[kind]=loadSource(kind)||{ok:false};
 updateSourceUI();
};
function collectSource(kind,force=false){
 if(!(kind in SOURCE_LABELS)||demo||typeof window.TEMPO_NATIVE==='undefined')return;
 if(sourcePending[kind])return;
 if(!force&&sources[kind]?.ok&&!sources[kind].cached&&Date.now()-sources[kind].fetchedAt<SOURCE_TTL[kind])return;
 sourcePending[kind]=true;
 window.TEMPO_NATIVE.fetchData(kind);
}
function updateSourceUI(){
 const cm=sources.cemaden,es=sources.estado,an=sources.ana,im=sources.inmet;
 const ese=stateEsteio(es),river=$('#river-value');
 if(river)river.textContent=an?.ok&&an.levelM!=null?numv(an.levelM,2)+' m':'-- m';
 let rm=$('#river-meta');if(rm)rm.textContent=an?.ok?`ANA · São Leopoldo · ${freshness('ana',an).label}`:'ANA · São Leopoldo · indisponível';
 let cmVal=$('#cemaden24');if(cmVal)cmVal.textContent=cm?.ok&&cm.h24!=null?numv(cm.h24,1)+' mm':'-- mm';
 let cmMeta=$('#cemaden-meta');if(cmMeta)cmMeta.textContent=cm?.ok?`G2-Colonial · ${freshness('cemaden',cm).label}`:'CEMADEN · indisponível';
 let dVal=$('#dcrs-temp');if(dVal)dVal.textContent=ese?.temperatura!=null?numv(ese.temperatura,1)+' °C':'-- °C';
 let dMeta=$('#dcrs-meta');if(dMeta)dMeta.textContent=es?.ok?`DCRS-00119 · ${freshness('estado',es).label}`:'Defesa Civil RS · indisponível';
 let list=$('#live-source-list');if(list){
  list.innerHTML=Object.keys(SOURCE_LABELS).map(k=>{
    const o=sources[k],f=freshness(k,o),detail=k==='ana'?o?.readingAt:k==='cemaden'?o?.readingAt:k==='estado'?stateEsteio(o)?.timestamp:o?.fetchedAt?new Date(o.fetchedAt).toLocaleString('pt-BR'):'';
    return `<div class="live-source"><div><strong>${SOURCE_LABELS[k]}</strong><small>${str(detail?fmtReading(detail):'Fonte ainda não consultada')}</small></div><span class="live-state ${f.level==='on'?'':f.level}">${sourcePending[k]?'Consultando…':str(f.label)}</span></div>`;
  }).join('');
 }
 renderOfficialAlerts();
 if(page==='detail' && window.detailTopic)renderDetail(window.detailTopic);
}
function renderOfficialAlerts(){
 const box=$('#alert-state'),list=$('#official-alerts-list'),o=sources.inmet;if(!box||!list)return;
 if(!o||!o.ok){box.innerHTML=`${icon('info')}<div><strong>Avisos INMET não verificados</strong><p>Sem leitura confirmada nesta consulta. Consulte os canais oficiais; isso não significa ausência de risco.</p></div>`;list.innerHTML='';return;}
 const f=freshness('inmet',o), alerts=o.alerts||[];
 if(o.cached){box.innerHTML=`${icon('info')}<div><strong>Últimos avisos salvos</strong><p>Sem atualização atual; confirme no portal INMET antes de usar.</p></div>`;}
 else if(!alerts.length){box.innerHTML=`${icon('info')}<div><strong>Sem avisos ativos do INMET encontrados</strong><p>Consulta realizada ${new Date(o.fetchedAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}. Alertas de outras instituições devem ser consultados separadamente.</p></div>`;}
 else{box.innerHTML=`${icon('warning')}<div><strong>${alerts.length} aviso(s) ativo(s) do INMET</strong><p>Consulte a validade e as orientações completas no portal do INMET.</p></div>`;}
 list.innerHTML=alerts.map(a=>`<div class="alert-row"><strong>${str(a.titulo)}</strong><small>Severidade: ${str(a.severidade)}<br>Início: ${str(a.inicio)} · Fim: ${str(a.fim)}<br>Fonte: INMET · Sapucaia do Sul</small></div>`).join('');
}
function renderLiveDetail(which){
 const cm=sources.cemaden,es=sources.estado,an=sources.ana;
 if(which==='chuvas'){
  if(!cm?.ok)return `<div class="white-card detail-data"><p><span class="source-badge error">Leitura não confirmada</span></p><p>Não foi possível obter os dados da estação CEMADEN G2-Colonial. Sem dados não significa chuva zero.</p><p>Consulte o mapa oficial do CEMADEN para conferir as medições.</p></div>`;
  const s=freshness('cemaden',cm);
  return `<div class="white-card detail-data"><span class="source-badge ${s.level==='on'?'':'stale'}">${str(s.label)}</span><h2>CEMADEN — G2-Colonial</h2><p>Estação 4331 · Sapucaia do Sul · observações de pluviômetro</p><div class="metric-block">${metric('Última 1 hora',numv(cm.h1,1)+' mm')}${metric('Últimas 6 horas',numv(cm.h6,1)+' mm')}${metric('Últimas 12 horas',numv(cm.h12,1)+' mm')}${metric('Últimas 24 horas',numv(cm.h24,1)+' mm')}</div><p>Referência do relatório: ${str(cm.readingAt)}</p></div>`;
 }
 if(which==='rio'){
   if(!an?.ok)return `<div class="white-card detail-data"><p><span class="source-badge error">ANA indisponível</span></p><p>Leitura da estação São Leopoldo (87382000) ainda não disponível. Abra a telemetria ANA ou o TEMPO web.</p></div>`;
   const s=freshness('ana',an);
   return `<div class="white-card detail-data"><span class="source-badge ${s.level==='on'?'':'stale'}">${str(s.label)}</span><h2>Rio dos Sinos — São Leopoldo</h2><p>Estação fluviométrica ANA 87382000. A medição é de São Leopoldo, não de Sapucaia.</p><div class="metric-block">${metric('Nível medido',numv(an.levelM,2)+' m')}${metric('Vazão',numv(an.flowM3s,1)+' m³/s')}</div><p>Leitura: ${str(an.readingAt)}</p><p>Fonte: ANA / HidroWebService. Não utilizar limiares locais sem aferição e referência oficial.</p></div>`;
 }
 if(which==='sensores'){
    const list=es?.stations||[];const e=stateEsteio(es);if(!es?.ok)return `<div class="white-card detail-data"><span class="source-badge error">Rede estadual indisponível</span><p>Consulte a plataforma de monitoramento da Defesa Civil RS.</p></div>`;
    return `<div class="white-card detail-data"><h2>Rede hidrometeorológica — Defesa Civil RS</h2><p>Estação de referência: Esteio (DCRS-00119). Listagem: outras estações identificadas na bacia do Sinos e arredores.</p><div class="metric-block">${metric('Temperatura em Esteio',numv(e?.temperatura,1)+' °C')}${metric('Chuva 24h em Esteio',numv(e?.chuva24,1)+' mm')}${metric('Vento médio',numv(e?.ventoMedio,1)+' km/h')}${metric('Rajadas',numv(e?.ventoRajada,1)+' km/h')}</div>${list.slice(0,18).map(s=>`<div class="station-row"><strong>${str(s.nome)} · ${str(s.codigo)}</strong>Temperatura ${numv(s.temperatura,1)} °C · Chuva 24h ${numv(s.chuva24,1)} mm${s.rioNivel!=null?' · Rio '+numv(s.rioNivel,2)+' m':''}<br><small>${str(s.timestamp||'Sem horário')} · ${s.manutencao?'Em manutenção':'Situação da estação: consultar fonte'}</small></div>`).join('')}</div>`;
 }
 if(which==='vento'){
    const e=stateEsteio(es);if(!e)return '';
    return `<div class="white-card detail-data"><h2>Vento medido — Esteio</h2><p>Estação estadual DCRS-00119. Não é medição direta em Sapucaia.</p><div class="metric-block">${metric('Velocidade média',numv(e.ventoMedio,1)+' km/h')}${metric('Velocidade máxima',numv(e.ventoRajada,1)+' km/h')}${metric('Direção',e.ventoDirecao==null?'--':dirName(e.ventoDirecao))}${metric('Leitura',str(e.timestamp||'--'))}</div></div>`;
 }
 return '';
}
function startSensorMonitoring(){
 for(const k of Object.keys(SOURCE_LABELS)){sources[k]=loadSource(k)||{ok:false};collectSource(k);}
 updateSourceUI();
 setInterval(()=>{if(!document.hidden&&navigator.onLine)for(const k of Object.keys(SOURCE_LABELS))collectSource(k);},60000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden&&navigator.onLine)for(const k of Object.keys(SOURCE_LABELS))collectSource(k);});
 window.addEventListener('online',()=>{for(const k of Object.keys(SOURCE_LABELS))collectSource(k,true);});
}

function init(){
 document.querySelectorAll('[data-go]').forEach(el=>el.addEventListener('click',()=>goto(el.dataset.go)));
 $('#refresh-btn').addEventListener('click',()=>{if(demo)displayDemo();else {updateWeather(true);for(const k of Object.keys(SOURCE_LABELS))collectSource(k,true);}});
 let dark=localStorage.getItem('tempo_dark')==='1';
 function theme(){document.documentElement.dataset.theme=dark?'dark':'light';$('#toggle-theme').textContent=dark?'Modo claro':'Modo escuro';}
 $('#toggle-theme').addEventListener('click',()=>{dark=!dark;localStorage.setItem('tempo_dark',dark?'1':'0');theme();});theme();
 window.TEMPOBack=()=>{if(page==='detail')goto('monitorar');else goto('inicio');};
 document.addEventListener('keydown',evt=>{if(evt.key==='Escape'||evt.key==='Backspace'){if(page!=='inicio'){evt.preventDefault();window.TEMPOBack();}}});
 window.addEventListener('online',()=>{if(!demo)updateWeather(true)});
 window.addEventListener('offline',()=>setConnection('error','Conexão indisponível — os dados podem estar desatualizados.'));
 if(demo)displayDemo();else {updateWeather();startSensorMonitoring();}
}
document.addEventListener('DOMContentLoaded',init);
// A versão web pode ser instalada como PWA após hospedagem HTTPS.
if ('serviceWorker' in navigator && location.protocol==='https:' && location.hostname!=='appassets.androidplatform.net') {
  window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
}
