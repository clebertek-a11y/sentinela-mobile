// Cache somente da interface; dados oficiais e previsões não são interceptados.
const CACHE='tempo-ui-v0.1.0';
const STATIC=['./index.html','./style.css','./app.js','./img/logo_tempo.webp','./img/sapucaia.webp','./img/brasao_sapucaia.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(STATIC))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(url.origin!==self.location.origin||event.request.method!=='GET')return;
 event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));
});
