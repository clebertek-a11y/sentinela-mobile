# TEMPO — Android (piloto 0.2.0)

Aplicativo **TEMPO — Tecnologia Estratégica Móvel para Previsão Operacional**, Sapucaia do Sul (RS). Esta versão parte do projeto Android v0.1.0, da identidade visual fornecida pelo usuário (logotipo original, bandeira, brasão e foto da cidade) e da arquitetura de coleta do TEMPO web.

## Funcionalidades implementadas

- Tela inicial com previsão Open-Meteo por hora e sete dias, temperatura aparente, vento e precipitação **estimada**.
- Monitoramento via HTTPS diretamente no Android para quatro fontes: CEMADEN, Rede Hidrometeorológica da Defesa Civil RS, ANA e avisos ativos do INMET.
- **CEMADEN:** estação configurada no TEMPO web: `4331` (G2-Colonial, Sapucaia do Sul). Tentativa de consulta dos acumulados de 1, 6, 12 e 24 horas. **Janelas com lacunas retornam valor indisponível**, não zero.
- **Defesa Civil RS:** consulta GraphQL `Tags_data`, exatamente no formato documentado pelo Estado; estação de referência `DCRS-00119` (Esteio) e lista de estações selecionadas da bacia do Sinos e arredores. Temperatura, chuva, vento e, quando a estação possui sensor, nível de rio. Respeita intervalo de 5 minutos da API.
- **ANA:** tentativa de leitura da estação `87382000` (São Leopoldo, Rio dos Sinos), incluindo nível e vazão, conforme a consulta usada no TEMPO web original. Medição explicitamente localizada em **São Leopoldo**, jamais apresentada como régua de Sapucaia.
- **INMET:** tentativa de consulta de avisos ativos do município IBGE `4320008`, distinguindo falta de conexão de ausência de avisos.
- Detalhes de cada fonte com identificador, origem e horário da leitura. Última leitura válida salva localmente, identificada como **dado salvo**, sem simular atualização.
- Acesso externo ao radar estadual, mapa do CEMADEN, ANA, avisos INMET, painel estadual, PLANO DE CONTINGÊNCIA 2026 da Prefeitura e contatos de emergência.
- Interface adaptada para Android, modo escuro, barras do sistema protegidas e opção de atualização manual das fontes.

## Limitações e validações pendentes

**Este pacote contém o código-fonte Android, não um APK já compilado.** O ambiente atual não dispõe de Android SDK e o projeto ainda não foi submetido a um fluxo de compilação no GitHub; não há APK nem teste físico validado nesta entrega.

As fontes externas foram identificadas pelo código original do TEMPO e por documentação pública. **Não foi possível verificar nesta sessão a resposta ao vivo dessas APIs dentro do Android.** O aplicativo foi programado para exibir falha/indisponibilidade e oferecer consultas oficiais em vez de inventar valores.

Em especial, a ANA anunciou migração do antigo webservice para o **HidroWebService** com autenticação. O acesso legado `telemetriaws1.ana.gov.br` do TEMPO original pode estar desativado ou defasado. Para leitura automática sustentada em produção, será preciso obter acesso à API atual da ANA e configurar uma integração segura, **sem embutir credenciais no APK**. A área do rio permanece explicitamente indisponível se a consulta antiga não retornar uma leitura válida.

A classificação operacional de nível e seus limiares **não deve ser inferida** de outra régua ou do valor isolado da estação. As categorias de risco só poderão ser aplicadas quando estiverem documentadas e vinculadas à referência de leitura correta.

Não existem notificações automáticas em segundo plano nesta versão; os avisos INMET são consultados com o aplicativo aberto. Avisos oficiais da Defesa Civil RS devem ser conferidos no canal próprio.

## Compilação APK — GitHub Actions (mesmo método do Sentinela)

1. Criar um **repositório próprio e independente** para o TEMPO no GitHub.
2. Descompactar o conteúdo da pasta `TEMPO_Android/` na raiz do novo repositório, incluindo `.github/workflows/android-apk.yml`.
3. Fazer commit na branch `main`. A ação **Compilar APK Android** será iniciada automaticamente; também pode ser disparada na aba Actions.
4. Após a compilação, baixar o artefato `TEMPO-Android-APK-teste` (arquivo ZIP) e extrair `app-debug.apk`.
5. Instalar em celular de teste, validando abertura, leitura de cada fonte, comportamento sem rede, tela escura/clara, teclados e navegação.

O APK `debug` destina-se a testes. Para distribuição pública, criar assinatura release segura e política de atualização. **Não reutilize chaves do Sentinela.** O `applicationId` do TEMPO é `br.com.iantzen.tempo` e sua numeração inicial é `0.2.0`.

## Referências e links

- Site TEMPO atual: https://temposapucaia.lovable.app/
- CEMADEN: https://www2.cemaden.gov.br/mapainterativo/
- Rede Defesa Civil RS: https://redehidrometeorologica.defesacivil.rs.gov.br/
- Documentação oficial da API RS: https://sistemas.defesacivil.rs.gov.br/api-redehidrometeorologica
- ANA (Hidro-Telemetria): https://www.snirh.gov.br/hidrotelemetria/
- ANA (acesso API HidroWeb): https://www.snirh.gov.br/hidroweb/acesso-api
- INMET: https://avisos.inmet.gov.br/
- Prefeitura/Plano de Contingência 2026: https://www.sapucaiadosul.rs.gov.br/wp-content/uploads/2026/08/Plano-de-Contingencia-Sapucaia-2026.pdf

## Testes técnicos realizados

- Verificação sintática de `app.js` com Node.js.
- Compilação sintática do `MonitorBridge.java` com Java e classes de substituição das APIs Android (não substitui compilação Android real).
- Validação XML do manifesto e estilo.
