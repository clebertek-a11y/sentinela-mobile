# SENTINELA Mobile — atualização independente da Play Store

Canal de atualizações: `br.gov.rs.sapucaiadosul.sentinela.atualizavel`, versão inicial **0.4.0**, `versionCode=10`.

## Como será para o agente

Ao abrir o aplicativo com conexão, ele consulta o catálogo público `updates/android-estavel.json` via HTTPS. Quando o `versionCode` publicado for maior que o instalado, apresenta **Nova versão disponível**, com a versão instalada, a nova, novidades e os botões **Atualizar agora** e **Depois**. Reexibe a mensagem em cada abertura enquanto desatualizado. `Configurações > Verificar atualizações` permite consulta manual. Sem internet, continua com registros offline.

O botão de atualização abre diretamente o APK publicado na página de Releases; a instalação depende de confirmação do Android. Não há instalação silenciosa e não é utilizado o mecanismo do Google Play.

## Correção fundamental: certificado permanente

Cada compilação antiga assinada pelo certificado de depuração temporário do servidor GitHub era incompatível com a seguinte. Para atualizações in-place sem apagar dados é necessária **a mesma chave de assinatura permanente**, o mesmo `applicationId` e um `versionCode` maior em cada APK. O projeto beta usa outro `applicationId` para poder ser instalado ao lado dos APKs antigos, sem exigir sua remoção. Os dados do aplicativo antigo não migram automaticamente para o novo canal.

Geramos uma chave PKCS#12 de assinatura exclusiva para este canal. Ela nunca é enviada ao repositório de código e deve ficar guardada com cópia de segurança segura. Os arquivos de chave e senha devem ser mantidos em posse do responsável autorizado; não são documentos públicos.

## Ativar a compilação de APK assinado no GitHub

No repositório GitHub, entrar em `Settings > Secrets and variables > Actions > New repository secret` e criar:

- `SENTINELA_KEYSTORE_BASE64`: conteúdo completo do arquivo `2_CHAVE_BASE64.txt` entregue de forma reservada, sem quebras extras.
- `SENTINELA_KEYSTORE_PASSWORD`: valor da segunda linha do arquivo `1_SENHA_CHAVE.txt`, entregue de forma reservada.

Depois acionar `Actions > Publicar APK atualizável > Run workflow`. O workflow só funciona após os dois segredos serem configurados, e conclui compilação, assinatura e conferência do APK, publica o arquivo no GitHub Release e atualiza `updates/android-estavel.json` para que os aparelhos reconheçam a nova versão ao abrir.

## Próximas versões

No arquivo `app/build.gradle.kts`, sempre aumentar `versionCode` (11, 12 etc.) e `versionName` (0.4.1, 0.4.2 etc.), sem modificar `applicationId` ou a chave. Validar a compilação e os testes antes de publicar. Após a publicação, o app passará a avisar sobre o novo APK.

O repositório atual está público: não inserir chaves, senhas, matrículas reais ou documentos de ocorrência. O mecanismo de catálogo deverá continuar publicamente acessível se o código-fonte for futuramente privado, preferivelmente por endpoint institucional ou repositório público exclusivo para releases.

**Limitações**: este piloto ainda não foi homologado para dados reais; backend institucional e sincronização entre aparelhos não estão implantados. A chave permanente criada agora é para testes. O controle e custódia institucional da assinatura devem ser formalizados pela TI antes de distribuição ampla.
