@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo SENTINELA Mobile - compilacao Android
where gradle >nul 2>&1
if errorlevel 1 (
 echo.
 echo Necessario Android Studio + Android SDK e Gradle ou Gradle Wrapper.
 echo Abra esta pasta como projeto no Android Studio.
 echo No Android Studio: Build ^> Build Bundle(s) / APK(s) ^> Build APK(s)
 echo Arquivo esperado: app\build\outputs\apk\debug\app-debug.apk
 pause
 exit /b 1
)
gradle assembleDebug
if errorlevel 1 (
 echo Falha na compilacao. Confira SDK e dependencias.
 pause
 exit /b 1
)
echo APK gerado em app\build\outputs\apk\debug\app-debug.apk
pause
