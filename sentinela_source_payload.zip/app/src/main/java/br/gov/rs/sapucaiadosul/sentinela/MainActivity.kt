package br.gov.rs.sapucaiadosul.sentinela

import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.app.job.JobScheduler
import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.text.method.HideReturnsTransformationMethod
import android.view.inputmethod.EditorInfo
import android.view.WindowManager
import android.content.pm.ApplicationInfo
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

class MainActivity : Activity() {
    private lateinit var store: LocalStore
    private var currentUser: User? = null
    private var attachmentIncidentId: String? = null
    private var cameraUri: Uri? = null
    private var selectedIncidentId: String? = null
    private var availableUpdate: UpdateChecker.Release? = null
    private var checkingUpdate = false
    private var pilotUnlockVerified = false
    private val prefs by lazy { getSharedPreferences("sync_settings", Context.MODE_PRIVATE) }

    private val navy = Color.rgb(20, 40, 73)
    private val orange = Color.rgb(242, 130, 37)
    private val bg = Color.rgb(246, 248, 251)
    private val ink = Color.rgb(28, 39, 58)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        store = LocalStore(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (store.hasUsers()) showLogin() else showBootstrap()
        checkForUpdates(false)
    }

    private fun isTestBuild() = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
    private fun sp(dp: Int) = (dp * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun shape(color: Int, radius: Int = 14) = GradientDrawable().apply {
        setColor(color); cornerRadius = sp(radius).toFloat()
    }
    private fun vertical(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(text: String, size: Float = 15f, bold: Boolean = false, color: Int = ink): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            setPadding(0, sp(5), 0, sp(5))
            if (bold) setTypeface(null, Typeface.BOLD)
        }
    private fun button(text: String, primary: Boolean = true, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 14f; isAllCaps = false
        setTextColor(if (primary) Color.WHITE else navy)
        background = shape(if (primary) navy else Color.rgb(228, 234, 242), 12)
        setPadding(sp(12), sp(11), sp(12), sp(11))
        setOnClickListener { onClick() }
    }
    private fun field(parent: LinearLayout, title: String, hint: String = "", value: String = "", password: Boolean = false): EditText {
        parent.addView(label(title, 13f, true))
        val multiline = title.contains("histórico", true) || title.contains("providências", true) || title.contains("descrição", true)
        val input = EditText(this).apply {
            setText(value); this.hint = hint; textSize = 16f; setTextColor(ink)
            setHintTextColor(Color.rgb(105, 114, 130))
            setSingleLine(!multiline)
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            imeOptions = if (multiline) EditorInfo.IME_FLAG_NO_ENTER_ACTION else EditorInfo.IME_ACTION_NEXT
            setPadding(sp(12), sp(12), sp(12), sp(12))
            setBackgroundColor(Color.TRANSPARENT)
            minHeight = sp(48)
        }
        val wrapper = row().apply {
            val outline = GradientDrawable().apply {
                setColor(Color.rgb(249, 251, 254)); cornerRadius = sp(10).toFloat()
                setStroke(sp(1), Color.rgb(171, 183, 202))
            }
            background = outline
        }
        wrapper.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        if (password) {
            val toggle = label("Mostrar", 13f, true, navy).apply {
                contentDescription = "Mostrar ou ocultar senha"
                setPadding(sp(9), sp(13), sp(12), sp(13))
                setOnClickListener {
                    val showing = input.transformationMethod !is PasswordTransformationMethod
                    input.transformationMethod = if (showing) PasswordTransformationMethod.getInstance() else HideReturnsTransformationMethod.getInstance()
                    text = if (showing) "Mostrar" else "Ocultar"
                    input.setSelection(input.text.length)
                }
            }
            wrapper.addView(toggle)
        }
        parent.addView(wrapper, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = sp(14) })
        return input
    }
    private fun section(content: LinearLayout, title: String): LinearLayout {
        val card = vertical().apply { background = shape(Color.WHITE, 16); setPadding(sp(15), sp(13), sp(15), sp(15)) }
        card.addView(label(title, 17f, true, navy))
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = sp(12) })
        return card
    }
    private fun screen(title: String, subtitle: String = "", back: (() -> Unit)? = null): LinearLayout {
        val root = vertical().apply { setBackgroundColor(bg) }
        val header = vertical().apply {
            setPadding(sp(20), sp(24), sp(20), sp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(navy, Color.rgb(38, 65, 105)))
        }
        if (back != null) header.addView(button("‹ Voltar", false, back), LinearLayout.LayoutParams(-2, -2).apply {bottomMargin = sp(10)})
        header.addView(label("SENTINELA • DEFESA CIVIL", 12f, true, orange))
        header.addView(label(title, 25f, true, Color.WHITE))
        if (subtitle.isNotBlank()) header.addView(label(subtitle, 12f, false, Color.rgb(215, 225, 237)))
        root.addView(header)
        val stripe = View(this).apply {setBackgroundColor(orange)}
        root.addView(stripe, LinearLayout.LayoutParams(-1, sp(4)))
        val body = vertical().apply { setPadding(sp(17), sp(17), sp(17), sp(44)) }
        root.addView(body, LinearLayout.LayoutParams(-1, -2))
        // O cabeçalho também rola, liberando espaço quando o teclado virtual está aberto.
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        scroll.addView(root)
        setContentView(scroll)
        return body
    }
    private fun canEdit() = currentUser?.role in setOf("ADMIN", "OPERADOR", "AGENTE")
    private fun canOpen() = currentUser?.role in setOf("ADMIN", "OPERADOR")

    private fun showBootstrap() {
        val body = screen("Primeiro acesso", "Cadastre o administrador deste aparelho")
        val c = section(body, "Cadastro inicial seguro")
        c.addView(label("Senha: mínimo de 8 caracteres, com letra maiúscula, minúscula, número e símbolo.", 13f))
        c.addView(label("Matrícula inicial sugerida: 93866. Defina sua senha diretamente aqui; ela não está embutida no aplicativo.", 12f))
        val nome = field(c, "Nome do administrador", value = "Cleber Iantzen")
        val mat = field(c, "Matrícula", value = "93866")
        val senha = field(c, "Senha de acesso", password = true)
        val confirmacao = field(c, "Confirmar senha", password = true)
        confirmacao.imeOptions = EditorInfo.IME_ACTION_DONE
        c.addView(button("Criar administrador") {
            if (senha.text.toString() != confirmacao.text.toString()) return@button toast("As senhas não coincidem")
            try {
                val u = store.createUser(nome.text.toString(), mat.text.toString(), "ADMIN", senha.text.toString())
                currentUser = u
                val code = store.issueRecoveryCode(u.id, u.id)
                showRecoveryCode(code) { dashboard() }
            } catch (e: Exception) { toast(e.message ?: "Falha ao cadastrar") }
        })
        if (isTestBuild()) {
            val demo = section(body, "Conta demonstrativa — somente testes")
            demo.addView(label("Para testar o aplicativo sem dados reais: matrícula 9999 e senha Boco@123. Não usar em atendimentos reais.", 12f))
            demo.addView(button("Criar usuário de teste 9999", false) {
                AlertDialog.Builder(this)
                    .setTitle("Ativar conta de teste?")
                    .setMessage("Cria um administrador local de demonstração com credenciais conhecidas. Nunca utilizar dados reais nesta versão.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Criar") { _, _ ->
                        try {
                            val u = store.createUser("Usuário de Teste", "9999", "ADMIN", "Boco@123")
                            currentUser = u; toast("Conta de teste criada"); dashboard()
                        } catch (e: Exception) { toast(e.message ?: "Não foi possível criar a conta") }
                    }.show()
            })
        }
    }

    private fun showLogin() {
        currentUser = null
        val body = screen("Acesso operacional", "SIGOPE e Boletim de Atendimento em um único aplicativo")
        val c = section(body, "Identificação")
        val mat = field(c, "Matrícula")
        val pass = field(c, "Senha", password = true)
        pass.imeOptions = EditorInfo.IME_ACTION_DONE
        c.addView(button("Entrar") {
            val matricula = mat.text.toString().trim()
            if (matricula.isBlank() || pass.text.isBlank()) return@button toast("Informe matrícula e senha")
            val user = store.login(matricula, pass.text.toString())
            if (user == null) toast("Acesso não autorizado. Confira a matrícula e a senha cadastradas neste aparelho.")
            else {
                currentUser = user
                if (user.mustChangePassword) changePasswordAtLogin(user) else dashboard()
            }
        })
        c.addView(button("Esqueci minha senha", false) { forgotPassword() })
        body.addView(label("Os usuários deste piloto são locais: uma conta de outro aparelho não acessa este. Caso não tenha um código de recuperação, procure o administrador.", 12f))
    }

    /** Código aleatório exibido somente uma vez. Não salvar senha nem código em relatórios ou logs. */
    private fun showRecoveryCode(code: String, onContinue: () -> Unit) {
        val message = label("Guarde este código em local seguro. Ele permite recuperar sua senha mesmo sem internet, uma única vez.\n\n$code\n\nDepois de utilizá-lo, será necessário solicitar outro ao administrador.", 17f, true)
        message.setTextIsSelectable(true)
        message.setPadding(sp(20), sp(15), sp(20), sp(15))
        AlertDialog.Builder(this).setTitle("Código de recuperação do SENTINELA")
            .setView(message).setCancelable(false)
            .setPositiveButton("Anotei e guardei o código") { _, _ -> onContinue() }.show()
    }

    private fun changePasswordAtLogin(user: User) {
        val body = screen("Trocar senha temporária", "Para proteger sua conta, defina uma senha pessoal.")
        val card = section(body, "Nova senha de ${user.matricula}")
        val password = field(card, "Nova senha", password = true)
        val confirm = field(card, "Confirmar nova senha", password = true)
        card.addView(button("Salvar senha e continuar") {
            if (password.text.toString() != confirm.text.toString()) return@button toast("As senhas não coincidem")
            try {
                store.changeOwnPassword(user.id, password.text.toString())
                currentUser = store.userByMatricula(user.matricula)
                toast("Senha atualizada. Acesso autorizado.")
                dashboard()
            } catch (e: Exception) {toast(e.message ?: "Não foi possível alterar senha")}
        })
        card.addView(button("Sair", false) {showLogin()})
    }

    private fun forgotPassword() {
        val body = screen("Esqueci minha senha", "Recuperação offline por código de uso único", ::showLogin)
        val card = section(body, "Redefinir senha")
        card.addView(label("Informe sua matrícula e o código entregue no cadastro ou pelo administrador. O código funciona uma única vez.", 13f))
        val mat = field(card, "Matrícula", value = "93866")
        val code = field(card, "Código de recuperação", "XXXX-XXXX-XXXX")
        val password = field(card, "Nova senha", password = true)
        val confirm = field(card, "Confirmar nova senha", password = true)
        card.addView(button("Redefinir senha") {
            if (password.text.toString() != confirm.text.toString()) return@button toast("As senhas não coincidem")
            try {
                if (store.recoverWithCode(mat.text.toString(), code.text.toString(), password.text.toString())) {
                    toast("Senha redefinida. Entre com sua matrícula e nova senha.")
                    showLogin()
                } else toast("Matrícula ou código de recuperação inválido ou já utilizado")
            } catch (e: Exception) {toast(e.message ?: "Não foi possível recuperar a senha")}
        })
        val info = section(body, "Não tenho código")
        info.addView(label("Peça ao administrador do SENTINELA que redefina sua senha ou emita novo código em Gestão de usuários. Sem servidor central, o aplicativo não envia e-mail ou SMS.", 13f))
        if (isTestBuild()) {
            info.addView(label("RECURSO EXCLUSIVO DO PILOTO: em aparelho com bloqueio de tela configurado, o proprietário pode autorizar recuperação local. Isso não verifica sua identidade institucional e será removido na versão de produção.", 12f))
            info.addView(button("Recuperar acesso deste aparelho (somente testes)",false) { confirmPilotDeviceOwner() })
        }
    }

    private fun confirmPilotDeviceOwner() {
        if (!isTestBuild()) return toast("Indisponível fora do piloto")
        val manager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!manager.isDeviceSecure) return toast("Configure PIN ou bloqueio de tela do Android; sem ele use o código de recuperação")
        val intent = manager.createConfirmDeviceCredentialIntent(
            "Recuperação local — SENTINELA TESTE", "Confirme o bloqueio do aparelho. Só use no seu dispositivo autorizado."
        ) ?: return toast("O Android não permite validação neste aparelho")
        pilotUnlockVerified = false
        startActivityForResult(intent, 104)
    }

    private fun pilotRecoveryScreen() {
        if (!isTestBuild() || !pilotUnlockVerified) return showLogin()
        pilotUnlockVerified = false // só uma operação por desbloqueio
        val body = screen("Recuperação de testes", "Confirmação do bloqueio do aparelho concluída", ::showLogin)
        val card = section(body, "Redefinir administrador local")
        card.addView(label("ATENÇÃO: somente piloto. A posse do celular não comprova vínculo com a Defesa Civil. Não utilizar com atendimentos reais.", 13f))
        val admins = store.users().filter { it.role == "ADMIN" && it.active }
        if (admins.isEmpty()) {
            card.addView(label("Não existe administrador ativo. Procure suporte técnico para recuperar a base local.", 13f))
            return
        }
        val names = admins.map { "${it.name} • ${it.matricula}" }
        val choose = Spinner(this).apply {adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)}
        card.addView(label("Administrador", 13f, true));card.addView(choose)
        val pass = field(card, "Nova senha", password = true)
        val confirm = field(card, "Confirmar nova senha", password = true)
        card.addView(button("Redefinir acesso de teste") {
            if (pass.text.toString() != confirm.text.toString()) return@button toast("As senhas não coincidem")
            try {
                val admin = admins[choose.selectedItemPosition]
                store.changeOwnPassword(admin.id, pass.text.toString())
                toast("Senha redefinida. Entre novamente.")
                showLogin()
            } catch (e: Exception) {toast(e.message ?: "Falha ao redefinir")}
        })
    }

    private fun dashboard() {
        val user = currentUser ?: return showLogin()
        val body = screen("Central de ocorrências", "${user.name} • ${user.role}")
        availableUpdate?.let { update ->
            val notice = section(body, "Atualização disponível: ${update.version}")
            notice.addView(label("Versão ${update.version} • Baixar APK de testes pelo GitHub", 12f))
            notice.addView(button("Ver atualização") { showUpdateDialog(update) })
        }
        val nav = section(body, "Acesso rápido")
        val controls = row()
        if (canOpen()) controls.addView(button("+ Nova ocorrência") { newIncident() }, LinearLayout.LayoutParams(0, -2, 1f).apply {rightMargin=sp(6)})
        controls.addView(button("Atualizar", false) { dashboard() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(controls)
        val controls2 = row()
        if (user.role == "ADMIN") controls2.addView(button("Usuários", false) { userManagement() }, LinearLayout.LayoutParams(0,-2,1f).apply {rightMargin=sp(6)})
        controls2.addView(button("Configurações", false) { settings() }, LinearLayout.LayoutParams(0,-2,1f))
        nav.addView(controls2)
        nav.addView(button("Sair", false) { showLogin() })
        val list = store.incidents()
        val countPending = list.count { it.syncState != "SINCRONIZADO" }
        body.addView(label("${list.size} registros • $countPending aguardando sincronização", 13f, true, navy))
        if (list.isEmpty()) body.addView(label("Nenhuma ocorrência cadastrada. Crie uma para testar o fluxo offline."))
        list.forEach { o ->
            val c = section(body, "${o.number}  •  ${o.status}")
            c.addView(label("${o.tipo} | ${o.prioridade}", 14f, true))
            c.addView(label("${o.rua} — ${o.bairro}\nSolicitante: ${o.solicitante}", 13f))
            c.addView(label("Arquivamento: ${o.syncState}", 12f, false, if (o.syncState=="SINCRONIZADO") Color.rgb(23,126,81) else orange))
            c.addView(button("Abrir atendimento →") { openIncident(o.id) })
        }
    }

    private fun newIncident() {
        if (!canOpen()) return toast("Somente operador ou administrador abre ocorrências")
        val body = screen("Nova ocorrência", "Registro local no SIGOPE", ::dashboard)
        val c = section(body, "Dados iniciais")
        val cat = Spinner(this)
        val categories = arrayOf("OCORRENCIAS", "VISTORIAS", "APOIOS OPERACIONAIS", "INTERDIÇÕES")
        cat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        c.addView(label("Categoria", 13f, true)); c.addView(cat)
        val solicitante = field(c,"Solicitante")
        val telefone = field(c,"Telefone")
        val rua = field(c,"Endereço (rua e número)")
        val bairro = field(c,"Bairro")
        val tipo = field(c,"Natureza da ocorrência", "Ex.: Queda de árvore")
        val descricao = field(c,"Descrição inicial")
        val equipe = field(c,"Equipe designada", "Ex.: Equipe 01")
        val prioridade = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Normal", "Baixa", "Alta", "Urgente"))
        }
        c.addView(label("Prioridade", 13f, true)); c.addView(prioridade)
        c.addView(button("Registrar ocorrência") {
            try {
                val item = store.createIncident(cat.selectedItem.toString(),solicitante.text.toString(),
                    telefone.text.toString(),rua.text.toString(),bairro.text.toString(),
                    tipo.text.toString(),descricao.text.toString(),equipe.text.toString(),
                    prioridade.selectedItem.toString(), currentUser!!.id)
                toast("Ocorrência ${item.number} criada offline"); openIncident(item.id)
            } catch (e: Exception) { toast(e.message ?: "Erro ao registrar") }
        })
    }

    private fun openIncident(id: String) {
        val o = store.incident(id) ?: return dashboard()
        selectedIncidentId = id
        val body = screen("Atendimento ${o.number}", "${o.category} • ${o.status}", ::dashboard)
        val c = section(body, "Dados recebidos")
        c.addView(label("${o.rua} — ${o.bairro}", 17f, true))
        c.addView(label("${o.tipo} • Prioridade: ${o.prioridade}", 13f))
        c.addView(label("Solicitante: ${o.solicitante}\nTelefone: ${o.telefone}\nEquipe: ${o.equipe}\n${o.descricao}", 14f))
        if (canEdit() && o.status != "Atendida") {
            val actions = section(body, "Andamento")
            if (o.status == "Aguardando atendimento") actions.addView(button("A caminho") {
                store.updateStatus(id,"Equipe deslocada",currentUser!!.id); openIncident(id)
            })
            if (o.status != "Em atendimento") actions.addView(button("Iniciar atendimento → abrir BA") {
                store.updateStatus(id, "Em atendimento", currentUser!!.id)
                reportScreen(id)
            })
            else actions.addView(button("Continuar boletim de atendimento") { reportScreen(id) })
            actions.addView(button("Aguardando apoio",false) {store.updateStatus(id,"Aguardando apoio",currentUser!!.id);openIncident(id)})
            actions.addView(button("Aguardando retorno",false) {store.updateStatus(id,"Aguardando retorno",currentUser!!.id);openIncident(id)})
        }
        val docs = section(body, "Documentos e situação")
        docs.addView(label("Fotos: ${store.photos(id).size}\nPDF: ${if (o.pdfPath.isNotEmpty()) "Gerado" else "Pendente"}\nSincronização: ${o.syncState}",13f))
        if (o.status == "Atendida") {
            docs.addView(button("Visualizar BA") { reportScreen(id) })
            docs.addView(button("Exportar pacote ZIP") { exportIncident(id) })
            if (o.syncState != "SINCRONIZADO") docs.addView(button("Tentar sincronizar", false) { SyncJobService.schedule(this); toast("Sincronização solicitada, se configurada e disponível") })
        }
        val trail = section(body, "Histórico de movimentações")
        store.audit(id).forEach { trail.addView(label(it, 12f)) }
    }

    private fun reportScreen(id: String) {
        val o = store.incident(id) ?: return dashboard()
        val old = store.report(id)
        val readonly = o.status == "Atendida" || !canEdit()
        val body = screen("Boletim de Atendimento", "${o.number} • ${o.rua}", { openIncident(id) })
        val c = section(body, "Dados do atendimento")
        c.addView(label("Solicitante: ${o.solicitante}\nLocal: ${o.rua} — ${o.bairro}\nNatureza: ${o.tipo}", 13f))
        val historico = field(c, "Histórico / constatações", value = old.historico)
        val providencias = field(c, "Providências adotadas", value = old.providencias)
        val responsavel = field(c, "Responsável presente no local",value=old.responsavel.ifBlank { o.solicitante })
        val doc = field(c, "Documento do responsável (quando informado)", value = old.responsavelDocumento)
        val outros = field(c, "Outros agentes (não assinam o BA)",value=old.outrosAgentes)
        val gps = field(c, "Localização / observações de GPS",value=old.gps)
        val signer = section(body, "Primeiro agente — assinatura cadastrada")
        signer.addView(label("A assinatura cadastrada será recuperada pela matrícula somente após confirmar a senha do agente.",12f))
        val mat = field(signer,"Matrícula do primeiro agente",value=old.agenteMatricula)
        var agentSignature = old.agenteSignature
        var agentName = old.agenteNome
        val agentLabel = label("Agente: ${old.agenteNome.ifBlank { "não identificado" }} • ${if (old.agenteSignature.isNotBlank()) "assinatura confirmada" else "sem assinatura"}", 12f)
        signer.addView(agentLabel)
        if (!readonly) signer.addView(button("Recuperar e confirmar assinatura",false) {
            val u = store.userByMatricula(mat.text.toString())
            if (u == null || u.signaturePath.isBlank()) return@button toast("Matrícula não cadastrada ou assinatura ausente")
            val pass = EditText(this).apply {
                hint = "Senha do agente ${u.name}"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            AlertDialog.Builder(this).setTitle("Confirmar assinatura de ${u.name}")
                .setMessage("O agente deve digitar sua própria senha. O registro ficará vinculado ao BA ${o.number}.")
                .setView(pass)
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Confirmar") {_,_->
                    if (store.login(u.matricula,pass.text.toString())?.id != u.id) toast("Confirmação inválida")
                    else {
                        val snapshot = File(FileTools.dir(this,id),"assinatura_primeiro_agente.png")
                        File(u.signaturePath).copyTo(snapshot, overwrite = true)
                        agentSignature = snapshot.absolutePath; agentName = u.name
                        agentLabel.text = "Agente: ${u.name} • assinatura confirmada"
                        toast("Assinatura vinculada ao atendimento")
                    }
                }.show()
        })
        var responsibleSignature = old.responsavelSignature
        val resident = section(body, "Assinatura do responsável no local")
        val residentLabel = label(if (responsibleSignature.isBlank()) "Pendente" else "Assinatura registrada",12f)
        resident.addView(residentLabel)
        if (!readonly) resident.addView(button("Coletar assinatura no celular",false) {
            collectSignature("Assinatura do responsável", File(FileTools.dir(this,id),"assinatura_responsavel.png")) { path ->
                responsibleSignature = path
                residentLabel.text = "Assinatura registrada"
            }
        })
        fun report(): Report = Report(id, historico.text.toString().trim(), providencias.text.toString().trim(),
            responsavel.text.toString().trim(),doc.text.toString().trim(),mat.text.toString().trim(),
            agentName,agentSignature,responsibleSignature,outros.text.toString().trim(),gps.text.toString().trim(), LocalStore.now())
        val photosBlock = section(body, "Registro fotográfico")
        val photoCounter = label("${store.photos(id).size} fotografia(s) armazenada(s) neste aparelho", 13f)
        photosBlock.addView(photoCounter)
        if (!readonly) {
            photosBlock.addView(button("Tirar fotografia") { saveDraft(report()); takePhoto(id) })
            photosBlock.addView(button("Selecionar da galeria",false) { saveDraft(report()); choosePhoto(id) })
        }
        store.photos(id).forEachIndexed { ix, _ -> photosBlock.addView(label("Foto ${ix+1} — salva localmente", 12f)) }
        val actions = section(body, "Gravação e conclusão")
        if (!readonly) {
            actions.addView(button("Salvar rascunho", false) { saveDraft(report()); toast("Rascunho salvo no aparelho") })
            actions.addView(button("Salvar BA e finalizar ocorrência") {
                val r = report()
                if (r.historico.isBlank() || r.providencias.isBlank()) return@button toast("Preencha histórico e providências")
                if (r.agenteSignature.isBlank() || !File(r.agenteSignature).exists()) return@button toast("Confirme a assinatura do primeiro agente")
                if (r.responsavelSignature.isBlank() || !File(r.responsavelSignature).exists()) return@button toast("Colete a assinatura do responsável")
                val photoList = store.photos(id)
                if (photoList.isEmpty()) return@button toast("Envie pelo menos uma fotografia antes de finalizar")
                try {
                    saveDraft(r)
                    val pdf = ReportPdf.generate(this, o, r, photoList)
                    store.conclude(id,pdf.absolutePath,currentUser!!.id)
                    SyncJobService.schedule(this)
                    toast("BA e ocorrência concluídos localmente. Arquivamento remoto pendente.")
                    openIncident(id)
                } catch (e: Exception) { toast("Erro ao gerar BA: ${e.message}") }
            })
        } else actions.addView(label("Atendimento concluído. As alterações e novas assinaturas estão bloqueadas nesta versão.", 12f))
    }

    private fun saveDraft(r: Report) { store.saveReport(r, currentUser!!.id) }

    private fun collectSignature(title: String, target: File, onSaved: (String)->Unit) {
        val holder = vertical().apply {setPadding(sp(12),sp(12),sp(12),sp(12))}
        val canvas = SignatureView(this)
        holder.addView(label("Assine na área branca abaixo com o dedo.",13f))
        holder.addView(canvas, LinearLayout.LayoutParams(-1,sp(220)))
        holder.addView(button("Limpar",false) {canvas.clear()})
        AlertDialog.Builder(this).setTitle(title).setView(holder)
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Salvar") {_,_->
                if (canvas.saveTo(target)) {onSaved(target.absolutePath); toast("Assinatura salva")}
                else toast("Assinatura vazia. Repita a coleta")
            }.show()
    }

    private fun takePhoto(id: String) {
        attachmentIncidentId = id
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME,"SENTINELA_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Sentinela")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
        if (uri == null) return toast("Não foi possível iniciar a câmera")
        cameraUri = uri
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {putExtra(MediaStore.EXTRA_OUTPUT,uri); addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}
        try { startActivityForResult(intent,101) } catch (e: Exception) {toast("Câmera indisponível: ${e.message}")}
    }

    private fun choosePhoto(id: String) {
        attachmentIncidentId = id
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent,102)
    }

    @Deprecated("Compatibilidade com o fluxo mínimo do piloto")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 104) {
            if (resultCode == RESULT_OK && isTestBuild()) {
                pilotUnlockVerified = true
                pilotRecoveryScreen()
            } else toast("Autorização do aparelho não confirmada")
            return
        }
        val id = attachmentIncidentId ?: return
        if (resultCode != RESULT_OK) { cameraUri = null; return }
        if (requestCode == 103) { data?.data?.let { writeExport(it, id) }; return }
        val uri = if (requestCode==101) cameraUri else data?.data
        cameraUri = null
        if (uri != null) {
            try {
                val (compressed, original) = FileTools.importPhoto(this,id,uri)
                store.addPhoto(id,compressed.absolutePath,original.absolutePath,currentUser!!.id)
                toast("Foto salva localmente. Cópia original preservada.")
            } catch (e: Exception) { toast("Não foi possível importar imagem: ${e.message}") }
        }
        reportScreen(id)
    }

    private fun userManagement() {
        if (currentUser?.role != "ADMIN") return dashboard()
        val body = screen("Gestão de usuários", "Edição, perfis, senhas e assinaturas", ::dashboard)
        val intro = section(body, "Contas deste aparelho")
        intro.addView(label("Apenas o administrador pode editar cadastros ou redefinir senhas. As alterações são locais e não afetam outros celulares.", 12f))
        store.users().forEach { u ->
            val status = if (u.active) "ATIVO" else "INATIVO"
            val c = section(body,"${u.name} • ${u.matricula}")
            c.addView(label("Perfil: ${u.role} • $status • Assinatura: ${if(u.signaturePath.isBlank()) "pendente" else "cadastrada"}",12f))
            c.addView(button("Editar cadastro e permissões",false) { editUserScreen(u.id) })
            c.addView(button("Redefinir senha",false) { resetUserPasswordScreen(u.id) })
            c.addView(button("Gerar novo código de recuperação",false) {
                AlertDialog.Builder(this).setTitle("Substituir código de recuperação?")
                    .setMessage("O código anterior deixará de funcionar. Entregue o novo código apenas ao titular desta conta.")
                    .setNegativeButton("Cancelar",null)
                    .setPositiveButton("Gerar") {_,_->
                        try {showRecoveryCode(store.issueRecoveryCode(u.id, currentUser!!.id)) {userManagement()}}
                        catch (e: Exception) {toast(e.message ?: "Falha ao gerar código")}
                    }.show()
            })
            if (u.active) c.addView(button("Cadastrar / atualizar assinatura",false) {
                val dest = File(filesDir,"assinaturas/${u.id}.png")
                collectSignature("Assinatura cadastrada de ${u.name}",dest) { path ->
                    store.saveRegisteredSignature(u.id,path); userManagement()
                }
            })
        }
        val c = section(body,"Novo usuário")
        val name = field(c,"Nome")
        val mat = field(c,"Matrícula")
        val password = field(c,"Senha inicial",password=true)
        val confirmPassword = field(c,"Confirmar senha",password=true)
        c.addView(label("Mínimo: 8 caracteres com maiúscula, minúscula, número e símbolo. A troca será exigida no primeiro login.", 12f))
        val roles = arrayOf("AGENTE", "OPERADOR", "CONSULTA", "ADMIN")
        val role = Spinner(this).apply {adapter = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,roles)}
        c.addView(label("Função",13f,true));c.addView(role)
        c.addView(button("Cadastrar usuário") {
            if (password.text.toString() != confirmPassword.text.toString()) return@button toast("As senhas não coincidem")
            try {
                val u = store.createUser(name.text.toString(),mat.text.toString(),role.selectedItem.toString(),password.text.toString())
                store.requirePasswordChange(u.id, currentUser!!.id)
                toast("Usuário cadastrado: ${u.matricula}")
                userManagement()
            } catch (e: Exception) {toast(e.message ?: "Falha no cadastro")}
        })
    }

    private fun editUserScreen(userId: String) {
        val me = currentUser ?: return showLogin()
        if (me.role != "ADMIN") return dashboard()
        val u = store.userById(userId) ?: return userManagement()
        val body = screen("Editar usuário", u.matricula, ::userManagement)
        val c = section(body,"Dados e permissões")
        val name = field(c,"Nome completo",value=u.name)
        val mat = field(c,"Matrícula",value=u.matricula)
        val roles = arrayOf("AGENTE", "OPERADOR", "CONSULTA", "ADMIN")
        val role = Spinner(this).apply {adapter = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,roles)}
        role.setSelection(roles.indexOf(u.role).coerceAtLeast(0))
        c.addView(label("Função",13f,true));c.addView(role)
        val active = CheckBox(this).apply {text = "Conta ativa";isChecked=u.active;setTextColor(ink)}
        c.addView(active)
        c.addView(button("Salvar alterações") {
            try {
                store.updateUser(u.id,name.text.toString(),mat.text.toString(),role.selectedItem.toString(),active.isChecked,me.id)
                toast("Cadastro atualizado"); userManagement()
            } catch (e: Exception) {toast(e.message ?: "Não foi possível atualizar")}
        })
    }

    private fun resetUserPasswordScreen(userId: String) {
        val admin = currentUser ?: return showLogin()
        if (admin.role != "ADMIN") return dashboard()
        val target = store.userById(userId) ?: return userManagement()
        val body = screen("Redefinir senha", "${target.name} • ${target.matricula}", ::userManagement)
        val c = section(body,"Nova credencial")
        c.addView(label("A senha anterior não será exibida. Informe uma nova senha e repasse-a diretamente ao usuário. Ele deverá trocá-la ao entrar.", 13f))
        val pass = field(c,"Nova senha",password=true)
        val confirm = field(c,"Confirmar nova senha",password=true)
        c.addView(button("Confirmar redefinição") {
            if (pass.text.toString() != confirm.text.toString()) return@button toast("As senhas não coincidem")
            try {
                store.resetPasswordByAdmin(target.id,pass.text.toString(),admin.id)
                toast("Senha redefinida. Peça ao usuário que entre com a nova senha.")
                userManagement()
            } catch (e: Exception) {toast(e.message ?: "Não foi possível redefinir")}
        })
    }

    private fun settings() {
        val body = screen("Configurações", "Arquivamento e sincronização", ::dashboard)
        val updates = section(body,"Atualizações")
        updates.addView(label("Versão instalada: ${UpdateChecker.installedVersion(this)}", 13f, true))
        updates.addView(button("Verificar atualizações",false) {checkForUpdates(true)})
        updates.addView(label("A instalação de APK exige sua autorização. A atualização preserva dados apenas com assinatura digital compatível. Para os testes iniciais, exporte os boletins antes de reinstalar.",12f))
        val c = section(body,"Servidor independente")
        c.addView(label("Para enviar dados automaticamente, é necessário um serviço HTTPS independente acessível pelo aparelho. Não apontar diretamente para \\servidor02\\Comp.",13f))
        val url = field(c,"URL HTTPS de sincronização", "https://servidor.exemplo.br/api/v1/atendimentos/arquivo", prefs.getString("url","")?:"")
        val token = field(c,"Token de autenticação do dispositivo",value=SecureSecrets.read(this),password=true)
        c.addView(button("Salvar configuração") {
            val address = url.text.toString().trim()
            if(address.isNotBlank() && !address.startsWith("https://")) return@button toast("Use exclusivamente HTTPS")
            prefs.edit().putString("url",address).apply()
            SecureSecrets.save(this,token.text.toString().trim())
            SyncJobService.schedule(this)
            toast("Configuração salva. Sem servidor disponível, permanecerá pendente.")
        })
        val warn = section(body,"Segurança e dados locais")
        warn.addView(label("Dados armazenados no espaço privado do aplicativo. Não limpe os dados nem desinstale antes de exportar e confirmar o arquivamento. Senhas possuem hash com salt. O piloto ainda não oferece criptografia de banco ou backup remoto completo.",13f))
        warn.addView(label("O aplicativo não usa o banco SIGOPE ou BA da Lovable.",13f,true))
    }

    private fun checkForUpdates(interactive: Boolean) {
        if (checkingUpdate) {
            if (interactive) toast("Consulta de atualização em andamento")
            return
        }
        checkingUpdate = true
        Thread {
            val result = runCatching { UpdateChecker.findNewerRelease(this, isTestBuild()) }
            runOnUiThread {
                checkingUpdate = false
                result.onSuccess { release ->
                    if (release != null) {
                        availableUpdate = release
                        // Avisar uma vez por versão, para não interromper o agente a cada abertura.
                        val last = prefs.getString("last_update_prompt", "")
                        if (interactive || last != release.version) {
                            prefs.edit().putString("last_update_prompt", release.version).apply()
                            showUpdateDialog(release)
                        }
                    } else if (interactive) toast("Nenhuma versão mais recente disponível")
                }.onFailure {
                    if (interactive) toast("Não foi possível verificar atualizações. Confira sua conexão.")
                }
            }
        }.start()
    }

    private fun showUpdateDialog(release: UpdateChecker.Release) {
        AlertDialog.Builder(this)
            .setTitle("Nova versão do SENTINELA: ${release.version}")
            .setMessage("Versão instalada: ${UpdateChecker.installedVersion(this)}\n\n${release.notes.take(700)}\n\nAntes de substituir um APK de testes, exporte seus documentos. A instalação sobre a anterior só funciona quando as assinaturas digitais são compatíveis.")
            .setNegativeButton("Depois", null)
            .setPositiveButton("Abrir download") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(release.apkUrl))) }
                catch (_: Exception) { toast("Navegador indisponível para baixar a atualização") }
            }.show()
    }

    private fun exportIncident(id: String) {
        val o = store.incident(id) ?: return
        try {
            val zip = FileTools.archive(this,o,store.report(id),store.photos(id))
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"; putExtra(Intent.EXTRA_TITLE,zip.name)
            }
            attachmentIncidentId = id
            startActivityForResult(intent,103)
        } catch (e: Exception) {toast("Falha ao preparar pacote: ${e.message}")}
    }

    private fun writeExport(target: Uri, incidentId: String) {
        val o=store.incident(incidentId)?:return
        val zip=FileTools.archive(this,o,store.report(incidentId),store.photos(incidentId))
        contentResolver.openOutputStream(target)?.use { dest -> zip.inputStream().use {it.copyTo(dest)} }
        toast("Pacote exportado. Copie-o para o servidor quando autorizado.")
    }
}
