package br.gov.rs.sapucaiadosul.sentinela

import android.content.Context
import org.json.JSONArray
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/** Consulta releases públicas para informar a existência de um APK mais recente.
 * Não instala silenciosamente nem armazena tokens de acesso ao GitHub no aplicativo.
 */
object UpdateChecker {
    data class Release(val version: String, val apkUrl: String, val notes: String)

    fun installedVersion(context: Context): String =
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.3.0"

    private fun number(version: String): List<Int>? {
        val match = Regex("""^v?(\d+)\.(\d+)\.(\d+)""").find(version) ?: return null
        return (1..3).map { match.groupValues[it].toIntOrNull() ?: return null }
    }

    private fun greater(a: String, b: String): Boolean {
        val lhs = number(a) ?: return false
        val rhs = number(b) ?: return false
        return (0..2).firstNotNullOfOrNull { i ->
            when {
                lhs[i] > rhs[i] -> true
                lhs[i] < rhs[i] -> false
                else -> null
            }
        } ?: false
    }

    fun findNewerRelease(context: Context, allowPrerelease: Boolean): Release? {
        val url = URL("https://api.github.com/repos/clebertek-a11y/sentinela-mobile/releases?per_page=15")
        val connection = (url.openConnection() as HttpsURLConnection).apply {
            connectTimeout = 7000; readTimeout = 7000
            setRequestProperty("User-Agent", "SentinelaMobile-Android")
            setRequestProperty("Accept", "application/vnd.github+json")
        }
        try {
            if (connection.responseCode != 200) throw IllegalStateException("Falha na consulta")
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val releases = JSONArray(body)
            val current = installedVersion(context)
            var newest: Release? = null
            for (index in 0 until releases.length()) {
                val item = releases.optJSONObject(index) ?: continue
                if (item.optBoolean("draft", true)) continue
                if (!allowPrerelease && item.optBoolean("prerelease", false)) continue
                val tag = item.optString("tag_name", "")
                if (!greater(tag, current)) continue
                val assets = item.optJSONArray("assets") ?: continue
                for (a in 0 until assets.length()) {
                    val asset = assets.optJSONObject(a) ?: continue
                    val download = asset.optString("browser_download_url", "")
                    if (!download.startsWith("https://github.com/clebertek-a11y/sentinela-mobile/releases/download/") ||
                        !download.endsWith(".apk", ignoreCase = true)) continue
                    if (newest == null || greater(tag, newest.version)) {
                        newest = Release(tag.removePrefix("v").substringBefore("-"), download,
                            item.optString("body", "Atualização disponível"))
                    }
                }
            }
            return newest
        } finally { connection.disconnect() }
    }
}
