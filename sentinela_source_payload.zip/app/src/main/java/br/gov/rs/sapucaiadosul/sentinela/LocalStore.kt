package br.gov.rs.sapucaiadosul.sentinela

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import java.time.LocalDate
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class User(
    val id: String, val name: String, val matricula: String,
    val role: String, val signaturePath: String
)

data class Incident(
    val id: String, val number: String, val date: String, val category: String,
    val solicitante: String, val telefone: String, val rua: String, val bairro: String,
    val tipo: String, val descricao: String, val equipe: String,
    val prioridade: String, val status: String, val pdfPath: String,
    val syncState: String
)

data class Report(
    val incidentId: String,
    val historico: String = "", val providencias: String = "",
    val responsavel: String = "", val responsavelDocumento: String = "",
    val agenteMatricula: String = "", val agenteNome: String = "",
    val agenteSignature: String = "", val responsavelSignature: String = "",
    val outrosAgentes: String = "", val gps: String = "", val atualizadoEm: String = ""
)

data class Photo(val id: String, val incidentId: String, val path: String, val originalPath: String, val createdAt: String)

class LocalStore(ctx: Context) : SQLiteOpenHelper(ctx, "sentinela_offline.db", null, 1) {
    private val prefs = ctx.getSharedPreferences("sentinela_prefs", Context.MODE_PRIVATE)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE users(
            id TEXT PRIMARY KEY, name TEXT NOT NULL, matricula TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL, salt TEXT NOT NULL, pw_hash TEXT NOT NULL,
            signature_path TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1
        )""")
        db.execSQL("""CREATE TABLE incidents(
            id TEXT PRIMARY KEY, number TEXT UNIQUE NOT NULL, date TEXT NOT NULL,
            category TEXT NOT NULL, solicitante TEXT NOT NULL, telefone TEXT NOT NULL,
            rua TEXT NOT NULL, bairro TEXT NOT NULL, tipo TEXT NOT NULL,
            descricao TEXT NOT NULL, equipe TEXT NOT NULL, prioridade TEXT NOT NULL,
            status TEXT NOT NULL, pdf_path TEXT NOT NULL DEFAULT '',
            sync_state TEXT NOT NULL DEFAULT 'PENDENTE', created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE reports(
            incident_id TEXT PRIMARY KEY REFERENCES incidents(id),
            historico TEXT NOT NULL DEFAULT '', providencias TEXT NOT NULL DEFAULT '',
            responsavel TEXT NOT NULL DEFAULT '', responsavel_documento TEXT NOT NULL DEFAULT '',
            agente_matricula TEXT NOT NULL DEFAULT '', agente_nome TEXT NOT NULL DEFAULT '',
            agente_signature TEXT NOT NULL DEFAULT '', responsavel_signature TEXT NOT NULL DEFAULT '',
            outros_agentes TEXT NOT NULL DEFAULT '', gps TEXT NOT NULL DEFAULT '',
            atualizado_em TEXT NOT NULL DEFAULT ''
        )""")
        db.execSQL("""CREATE TABLE photos(
            id TEXT PRIMARY KEY, incident_id TEXT NOT NULL REFERENCES incidents(id),
            path TEXT NOT NULL, original_path TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        db.execSQL("""CREATE TABLE audit(
            id INTEGER PRIMARY KEY AUTOINCREMENT, incident_id TEXT,
            action TEXT NOT NULL, user_id TEXT NOT NULL, created_at TEXT NOT NULL
        )""")
        db.execSQL("CREATE INDEX idx_incidents_date ON incidents(date)")
        db.execSQL("CREATE INDEX idx_photos_incident ON photos(incident_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Não apagar dados! Migrações incrementais serão adicionadas nas versões futuras.
        error("Migração de banco não suportada: $oldVersion → $newVersion")
    }

    fun hasUsers() = readableDatabase.rawQuery("SELECT 1 FROM users LIMIT 1", null).use { it.moveToFirst() }

    private fun derivePassword(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 210_000, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        } finally { spec.clearPassword() }
    }

    fun createUser(name: String, matricula: String, role: String, password: String): User {
        require(name.isNotBlank() && matricula.isNotBlank()) { "Informe nome e matrícula" }
        require(password.length >= 8 && password.any { it.isUpperCase() } &&
            password.any { it.isLowerCase() } && password.any { it.isDigit() } &&
            password.any { !it.isLetterOrDigit() }) {
            "Use 8 ou mais caracteres, com maiúscula, minúscula, número e símbolo"
        }
        require(role in setOf("ADMIN", "OPERADOR", "AGENTE", "CONSULTA")) { "Perfil inválido" }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val salt64 = android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP)
        val user = User(UUID.randomUUID().toString(), name.trim(), matricula.trim(), role, "")
        val cv = ContentValues().apply {
            put("id", user.id); put("name", user.name); put("matricula", user.matricula)
            put("role", role); put("salt", salt64); put("pw_hash", derivePassword(password, salt))
        }
        writableDatabase.insertOrThrow("users", null, cv)
        return user
    }

    fun login(matricula: String, password: String): User? {
        return readableDatabase.rawQuery(
            "SELECT id,name,matricula,role,signature_path,salt,pw_hash FROM users WHERE matricula=? AND active=1",
            arrayOf(matricula.trim())
        ).use { c ->
            if (!c.moveToFirst()) return@use null
            val salt = android.util.Base64.decode(c.getString(5), android.util.Base64.NO_WRAP)
            val proposed = derivePassword(password, salt).toByteArray(Charsets.UTF_8)
            val recorded = c.getString(6).toByteArray(Charsets.UTF_8)
            if (!MessageDigest.isEqual(proposed, recorded)) null
            else User(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
        }
    }

    fun userByMatricula(mat: String): User? = readableDatabase.rawQuery(
        "SELECT id,name,matricula,role,signature_path FROM users WHERE matricula=? AND active=1", arrayOf(mat.trim())
    ).use { c -> if (c.moveToFirst()) c.user() else null }

    fun users(): List<User> = readableDatabase.rawQuery(
        "SELECT id,name,matricula,role,signature_path FROM users WHERE active=1 ORDER BY name", null
    ).use { c -> buildList { while (c.moveToNext()) add(c.user()) } }

    private fun Cursor.user() = User(getString(0), getString(1), getString(2), getString(3), getString(4))

    fun saveRegisteredSignature(userId: String, path: String) {
        val cv = ContentValues().apply { put("signature_path", path) }
        writableDatabase.update("users", cv, "id=?", arrayOf(userId))
    }

    @Synchronized fun createIncident(
        category: String, solicitante: String, telefone: String, rua: String,
        bairro: String, tipo: String, descricao: String, equipe: String, prioridade: String,
        author: String
    ): Incident {
        require(category in setOf("OCORRENCIAS", "VISTORIAS", "APOIOS OPERACIONAIS", "INTERDIÇÕES"))
        require(solicitante.isNotBlank() && rua.isNotBlank()) { "Informe solicitante e endereço" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val year = LocalDate.now().year
            val seq = db.rawQuery("SELECT COUNT(*) FROM incidents WHERE date LIKE ?", arrayOf("$year%"))
                .use { c -> c.moveToFirst(); c.getInt(0) + 1 }
            val tag = prefs.getString("device_tag", null) ?: UUID.randomUUID().toString().take(4).uppercase().also {
                prefs.edit().putString("device_tag", it).apply()
            }
            // Número local rastreável e único por instalação; central deverá atribuir protocolo oficial.
            val number = "$year-$tag-${seq.toString().padStart(4, '0')}"
            val item = Incident(UUID.randomUUID().toString(), number, LocalDate.now().toString(), category,
                solicitante.trim(), telefone.trim(), rua.trim(), bairro.trim(), tipo.trim(),
                descricao.trim(), equipe.trim(), prioridade, "Aguardando atendimento", "", "PENDENTE")
            val cv = ContentValues().apply {
                put("id", item.id); put("number", number); put("date", item.date)
                put("category", item.category); put("solicitante", item.solicitante)
                put("telefone", item.telefone); put("rua", item.rua); put("bairro", item.bairro)
                put("tipo", item.tipo); put("descricao", item.descricao); put("equipe", item.equipe)
                put("prioridade", item.prioridade); put("status", item.status)
                put("created_at", now()); put("updated_at", now())
            }
            db.insertOrThrow("incidents", null, cv)
            logAction(db, item.id, "Ocorrência aberta: $number", author)
            db.setTransactionSuccessful()
            return item
        } finally { db.endTransaction() }
    }

    fun incidents(): List<Incident> = readableDatabase.rawQuery(
        "SELECT id,number,date,category,solicitante,telefone,rua,bairro,tipo,descricao,equipe,prioridade,status,pdf_path,sync_state " +
            "FROM incidents ORDER BY created_at DESC", null
    ).use { c -> buildList { while (c.moveToNext()) add(c.incident()) } }

    fun incident(id: String): Incident? = readableDatabase.rawQuery(
        "SELECT id,number,date,category,solicitante,telefone,rua,bairro,tipo,descricao,equipe,prioridade,status,pdf_path,sync_state FROM incidents WHERE id=?",
        arrayOf(id)
    ).use { c -> if (c.moveToFirst()) c.incident() else null }

    private fun Cursor.incident() = Incident(
        getString(0), getString(1), getString(2), getString(3), getString(4), getString(5),
        getString(6), getString(7), getString(8), getString(9), getString(10), getString(11),
        getString(12), getString(13), getString(14)
    )

    fun updateStatus(id: String, status: String, author: String) {
        require(status in setOf("Aguardando atendimento", "Equipe deslocada", "Em atendimento", "Aguardando apoio", "Aguardando retorno", "Atendida"))
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("status", status); put("updated_at", now()); put("sync_state", "PENDENTE")
        }
        db.beginTransaction()
        try {
            db.update("incidents", cv, "id=?", arrayOf(id))
            logAction(db, id, "Situação: $status", author)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun report(id: String): Report = readableDatabase.rawQuery(
        "SELECT incident_id,historico,providencias,responsavel,responsavel_documento,agente_matricula," +
            "agente_nome,agente_signature,responsavel_signature,outros_agentes,gps,atualizado_em FROM reports WHERE incident_id=?",
        arrayOf(id)
    ).use { c ->
        if (!c.moveToFirst()) Report(id)
        else Report(
            c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5),
            c.getString(6), c.getString(7), c.getString(8), c.getString(9), c.getString(10), c.getString(11)
        )
    }

    fun saveReport(report: Report, author: String) {
        val cv = ContentValues().apply {
            put("incident_id", report.incidentId); put("historico", report.historico)
            put("providencias", report.providencias); put("responsavel", report.responsavel)
            put("responsavel_documento", report.responsavelDocumento)
            put("agente_matricula", report.agenteMatricula); put("agente_nome", report.agenteNome)
            put("agente_signature", report.agenteSignature)
            put("responsavel_signature", report.responsavelSignature)
            put("outros_agentes", report.outrosAgentes); put("gps", report.gps)
            put("atualizado_em", now())
        }
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict("reports", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            db.update("incidents", ContentValues().apply {put("sync_state", "PENDENTE");put("updated_at", now())}, "id=?", arrayOf(report.incidentId))
            logAction(db, report.incidentId, "BA salvo", author)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun addPhoto(incidentId: String, path: String, originalPath: String, author: String): Photo {
        val photo = Photo(UUID.randomUUID().toString(), incidentId, path, originalPath, now())
        writableDatabase.insertOrThrow("photos", null, ContentValues().apply {
            put("id", photo.id); put("incident_id", incidentId); put("path", path)
            put("original_path", originalPath); put("created_at", photo.createdAt)
        })
        writableDatabase.update("incidents", ContentValues().apply { put("sync_state", "PENDENTE") }, "id=?", arrayOf(incidentId))
        logAction(writableDatabase, incidentId, "Fotografia anexada", author)
        return photo
    }

    fun photos(incidentId: String): List<Photo> = readableDatabase.rawQuery(
        "SELECT id,incident_id,path,original_path,created_at FROM photos WHERE incident_id=? ORDER BY created_at", arrayOf(incidentId)
    ).use { c -> buildList { while(c.moveToNext()) add(Photo(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4))) } }

    fun conclude(id: String, pdfPath: String, author: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.update("incidents", ContentValues().apply {
                put("status", "Atendida");put("pdf_path", pdfPath)
                put("sync_state", "PENDENTE");put("updated_at", now())
            }, "id=?", arrayOf(id))
            logAction(db, id, "BA e ocorrência concluídos localmente", author)
            db.setTransactionSuccessful()
        } finally {db.endTransaction()}
    }

    fun markSynced(id: String, author: String) {
        writableDatabase.update("incidents", ContentValues().apply { put("sync_state", "SINCRONIZADO") }, "id=?", arrayOf(id))
        logAction(writableDatabase, id, "Arquivado e sincronizado (ACK do servidor)", author)
    }

    fun audit(incidentId: String): List<String> = readableDatabase.rawQuery(
        "SELECT created_at, action FROM audit WHERE incident_id=? ORDER BY id DESC", arrayOf(incidentId)
    ).use { c -> buildList { while(c.moveToNext()) add("${c.getString(0)} — ${c.getString(1)}") } }

    private fun logAction(db: SQLiteDatabase, id: String?, action: String, author: String) {
        db.insert("audit", null, ContentValues().apply {
            put("incident_id", id);put("action", action);put("user_id", author);put("created_at", now())
        })
    }

    companion object { fun now(): String = java.time.OffsetDateTime.now().toString() }
}
