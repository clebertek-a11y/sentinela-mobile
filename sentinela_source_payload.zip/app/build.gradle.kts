plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.gov.rs.sapucaiadosul.sentinela"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.gov.rs.sapucaiadosul.sentinela"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { viewBinding = false }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
