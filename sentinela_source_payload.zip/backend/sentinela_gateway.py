#!/usr/bin/env python3
r"""Gateway interno HTTPS, opcional. Não expor à Internet pública.

Iniciar com variáveis:
  SENTINELA_ROOT = pasta autorizada (ex.: \\servidor02\Comp\SENTINELA)
  SENTINELA_TOKEN = segredo aleatório forte compartilhado com aparelhos autorizados
  SENTINELA_TLS_CERT = caminho para certificado TLS válido
  SENTINELA_TLS_KEY = caminho para chave privada do certificado
  SENTINELA_BIND = IP da VPN/rede privada (padrão 127.0.0.1)
  SENTINELA_PORT = 8443

Requer apenas Python 3.11+. Para teste restrito na LAN/VPN; TI deve configurar
certificado, firewall, conta de serviço, rotação de token e backup.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import re
import ssl
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import date
from zipfile import ZipFile, BadZipFile

ROOT = Path(os.environ.get('SENTINELA_ROOT', ''))
TOKEN = os.environ.get('SENTINELA_TOKEN', '')
CERT = os.environ.get('SENTINELA_TLS_CERT', '')
KEY = os.environ.get('SENTINELA_TLS_KEY', '')
BIND = os.environ.get('SENTINELA_BIND', '127.0.0.1')
PORT = int(os.environ.get('SENTINELA_PORT', '8443'))
MAX_BYTES = 70 * 1024 * 1024
MESES = ['01 - JANEIRO','02 - FEVEREIRO','03 - MARÇO','04 - ABRIL','05 - MAIO',
         '06 - JUNHO','07 - JULHO','08 - AGOSTO','09 - SETEMBRO',
         '10 - OUTUBRO','11 - NOVEMBRO','12 - DEZEMBRO']
CATEGORIES = {'OCORRENCIAS','VISTORIAS','APOIOS OPERACIONAIS','INTERDICOES'}
VALID_FILES = re.compile(r'^(BA_[A-Za-z0-9-]+\.pdf|FOTO_\d+\.jpg|manifest\.json)$')

def slug(value: str, limit: int = 110) -> str:
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '-', value)
    value = re.sub(r'\s+', ' ', value).strip(' .-')
    return value[:limit] or 'SEM_ENDERECO'

class Handler(BaseHTTPRequestHandler):
    def respond(self, code: int, **payload):
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path != '/api/v1/atendimentos/arquivo':
            return self.respond(404, error='not_found')
        auth = self.headers.get('Authorization', '')
        if not hmac.compare_digest(auth, f'Bearer {TOKEN}'):
            return self.respond(401, error='unauthorized')
        try:
            size = int(self.headers.get('Content-Length', '-1'))
            if size <= 0 or size > MAX_BYTES:
                return self.respond(413, error='invalid_size')
            incident_id = self.headers.get('X-Sentinela-Id', '')
            number = self.headers.get('X-Sentinela-Number', '')
            when = date.fromisoformat(self.headers.get('X-Sentinela-Date', ''))
            category = self.headers.get('X-Sentinela-Category', '')
            address = base64.b64decode(self.headers.get('X-Sentinela-Address-Base64',''), validate=True).decode('utf-8')
            desired_hash = self.headers.get('X-Sentinela-Sha256', '')
            if not re.fullmatch(r'[a-f0-9-]{36}', incident_id):
                return self.respond(400, error='invalid_id')
            if not re.fullmatch(r'[A-Z0-9-]{8,28}', number) or category not in CATEGORIES:
                return self.respond(400, error='invalid_metadata')
            blob = self.rfile.read(size)
            digest = hashlib.sha256(blob).hexdigest()
            if not hmac.compare_digest(digest, desired_hash):
                return self.respond(400, error='hash_mismatch')
            with ZipFile(io.BytesIO(blob)) as arc:
                infos = arc.infolist()
                if len(infos) > 120 or sum(i.file_size for i in infos) > MAX_BYTES*3:
                    return self.respond(413, error='archive_too_large')
                if any(not VALID_FILES.fullmatch(i.filename) or i.is_dir() for i in infos):
                    return self.respond(400, error='invalid_zip_entries')
                manifest = json.loads(arc.read('manifest.json'))
                if manifest.get('incident_id') != incident_id or manifest.get('number') != number:
                    return self.respond(400, error='invalid_manifest')
                folder = ROOT / str(when.year) / MESES[when.month-1] / (category if category!='INTERDICOES' else 'INTERDIÇÕES') / slug(number + ' - ' + address)
                folder.mkdir(parents=True, exist_ok=True)
                archive_target = folder / f'PACOTE_{number}.zip'
                if archive_target.exists():
                    if hashlib.sha256(archive_target.read_bytes()).hexdigest() != digest:
                        return self.respond(409, error='already_exists_different_content')
                else:
                    temp = archive_target.with_suffix('.tmp')
                    with open(temp, 'xb') as target:
                        target.write(blob)
                        target.flush(); os.fsync(target.fileno())
                    temp.replace(archive_target)
                for info in infos:
                    target = folder / info.filename
                    if not target.exists():
                        with open(target, 'xb') as out:
                            out.write(arc.read(info.filename))
                return self.respond(200, stored=True, incident_id=incident_id, sha256=digest)
        except (ValueError, KeyError, BadZipFile, UnicodeError, json.JSONDecodeError):
            return self.respond(400, error='bad_request')
        except Exception:
            return self.respond(503, error='archive_unavailable')

if __name__ == '__main__':
    if not TOKEN or len(TOKEN) < 32 or not CERT or not KEY or not os.environ.get('SENTINELA_ROOT'):
        raise SystemExit('Configure SENTINELA_ROOT, SENTINELA_TOKEN (>=32), SENTINELA_TLS_CERT e SENTINELA_TLS_KEY')
    if not ROOT.exists():
        raise SystemExit('A pasta raiz não existe; confirme a rede e as permissões')
    httpd = HTTPServer((BIND, PORT), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(CERT, KEY)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
    print(f'SENTINELA Gateway HTTPS escutando em {BIND}:{PORT}')
    httpd.serve_forever()
