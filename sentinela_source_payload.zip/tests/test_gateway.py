import base64
import hashlib
import http.client
import importlib.util
import io
import json
import pathlib
import tempfile
import threading
import unittest
import zipfile
from http.server import HTTPServer

PATH = pathlib.Path(__file__).resolve().parents[1] / 'backend' / 'sentinela_gateway.py'
spec = importlib.util.spec_from_file_location('sentinela_gateway', PATH)
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

class GatewayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        g.ROOT = pathlib.Path(self.tmp.name)
        g.TOKEN = 'token-de-teste-para-ambiente-local-123456789'
        self.server = HTTPServer(('127.0.0.1', 0), g.Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown(); self.thread.join(); self.server.server_close(); self.tmp.cleanup()

    def payload(self, incident_id='12345678-aaaa-bbbb-cccc-123456789abc'):
        obj = {'schema':'sentinela-1','incident_id':incident_id,'number':'2026-A1B2-0001','date':'2026-11-17','category':'OCORRENCIAS'}
        raw = io.BytesIO()
        with zipfile.ZipFile(raw,'w') as z:
            z.writestr('manifest.json',json.dumps(obj))
            z.writestr('BA_2026-A1B2-0001.pdf',b'%PDF-1.4 arquivo de teste')
            z.writestr('FOTO_01.jpg',b'jpgplaceholder')
        return raw.getvalue()

    def send(self, blob, token=None, address='Rua das Flores, 150'):
        c = http.client.HTTPConnection('127.0.0.1', self.server.server_address[1], timeout=5)
        head = {
            'Authorization': 'Bearer '+ (g.TOKEN if token is None else token),
            'X-Sentinela-Id':'12345678-aaaa-bbbb-cccc-123456789abc',
            'X-Sentinela-Number':'2026-A1B2-0001',
            'X-Sentinela-Date':'2026-11-17',
            'X-Sentinela-Category':'OCORRENCIAS',
            'X-Sentinela-Address-Base64':base64.b64encode(address.encode()).decode(),
            'X-Sentinela-Sha256':hashlib.sha256(blob).hexdigest(),
        }
        c.request('POST','/api/v1/atendimentos/arquivo',body=blob,headers=head)
        response=c.getresponse(); payload=json.loads(response.read());c.close()
        return response.status,payload

    def test_arquivamento_mes_endereco_idempotente(self):
        blob=self.payload()
        s,p=self.send(blob)
        self.assertEqual((s,p['stored']), (200,True))
        root=pathlib.Path(self.tmp.name)/'2026'/'11 - NOVEMBRO'/'OCORRENCIAS'/'2026-A1B2-0001 - Rua das Flores, 150'
        self.assertTrue((root/'PACOTE_2026-A1B2-0001.zip').exists())
        self.assertTrue((root/'FOTO_01.jpg').exists())
        self.assertEqual(self.send(blob)[0],200)

    def test_rejeita_token_invalido(self):
        self.assertEqual(self.send(self.payload(),token='invalido')[0],401)

    def test_normaliza_nome_invalido(self):
        self.assertNotIn('..',g.slug('../X:abc\\resto'))
        self.assertNotIn('/',g.slug('../X:abc\\resto'))

if __name__=='__main__': unittest.main()
