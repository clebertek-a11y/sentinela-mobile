# SENTINELA Mobile — Piloto 0.1 (Android independente)

**Situação: projeto Android nativo em código-fonte. Não é um APK. Não foi compilado nem validado em aparelho real.**

O projeto foi desenvolvido sem usar Lovable para hospedar, executar ou criar o aplicativo. O SIGOPE e o BA existentes serviram somente como referências funcionais. Não utiliza a base de dados dos projetos originais.

## O que está implementado no código

- App Android nativo escrito em Kotlin, interface em português, paleta azul-marinho/laranja inspirada no SIGOPE.
- Login por matrícula e senha com perfis ADMIN, OPERADOR, AGENTE, CONSULTA.
- Configuração inicial obrigatória de administrador, sem senha padrão.
- Cadastro local de usuários/agentes por nome, matrícula e função, com assinatura digital desenhada no dispositivo e armazenada no espaço privado do aplicativo.
- Registro local de ocorrências; classificação em OCORRENCIAS, VISTORIAS, APOIOS OPERACIONAIS e INTERDIÇÕES.
- Status “Aguardando atendimento”, “Equipe deslocada”, “Em atendimento”, “Aguardando apoio”, “Aguardando retorno”, “Atendida”.
- Botão “Iniciar atendimento” abre o BA na mesma aplicação, com dados do registro de origem.
- Cadastro de histórico, providências, responsável, matrícula do primeiro agente e lista de outros agentes.
- Recuperação da assinatura cadastrada do primeiro agente por matrícula, **exigindo senha desse agente** para vincular uma cópia àquele atendimento. Somente o primeiro agente assina o documento.
- Assinatura do responsável coletada pelo toque na tela, separada da assinatura do agente.
- Fotografia pela câmera e seleção pela galeria, mantendo arquivo original e uma cópia JPEG de alta qualidade (92%, dimensão máxima 3.000 pixels) para PDF e sincronização. Isso preserva a qualidade visual usual, **não é compressão matematicamente sem perdas**.
- Salvamento de rascunho e finalização com histórico, providências, as duas assinaturas e ao menos uma foto, gerando PDF com anexo fotográfico.
- Banco SQLite privado do Android e arquivos no diretório privado do aplicativo; sem conexão obrigatória durante cadastro e preenchimento.
- Exportação manual de pacote ZIP com PDF, fotos e manifesto.
- Serviço opcional de sincronização `JobScheduler`, com exigência de rede, HTTPS, autenticação por token protegido no Android Keystore, e confirmação de upload antes de registrar `SINCRONIZADO`.
- Gateway Python HTTPS de exemplo para arquivar em `\\servidor02\Comp\SENTINELA` conforme ano, mês, categoria e endereço (necessita implantação autorizada pela TI, configuração de certificado e acesso de rede).

## O que ainda precisa ser concluído antes do uso institucional

1. **Compilar e testar o APK em Android:** o ambiente de geração deste pacote não dispõe de Android SDK/Gradle e não consegue instalar tais ferramentas pela rede. Não se deve distribuir como aplicativo já testado.
2. **Logos oficiais:** o tema foi referenciado pelo código do SIGOPE, mas os arquivos originais dos brasões não puderam ser recuperados em formato binário adequado. O ícone do piloto é provisório. Substituir pela arte oficial autorizada.
3. **Segurança institucional:** o SQLite ainda não está cifrado em nível de banco de dados; os arquivos privados estão sujeitos às proteções do Android. Adicionar criptografia integral, revisão de papéis/permissões, revogação remota, trilha de auditoria imutável e política de retenção para produção.
4. **Identificação única central:** o número `2026-ABCD-0001` é **provisório por instalação**. Precisamos de servidor central para numeração oficial contínua sem colisão entre dispositivos offline. O identificador UUID já é único para sincronização.
5. **Identidade e sincronização multiaparelho:** os usuários cadastrados nesta primeira versão ficam apenas neste celular. É necessário criar cadastro central e emissão segura de credenciais para que os mesmos logins funcionem em vários celulares.
6. **Sync:** instalar e testar gateway HTTPS dentro da VPN/rede institucional. Sem endpoint configurado, a fila permanece pendente e os arquivos não vão automaticamente ao SERVIDOR02.
7. **Assinaturas:** confirmar o procedimento institucional de assinatura e eventual assinatura por ausência/recusa do responsável; pilot exige ambas.
8. **Integridade:** implementar assinatura digital do PDF, integração de backup, proteção contra perda de aparelho, tratamento de erros de câmera/galeria por fabricante e testes de recuperação.
9. **Distribuição:** gerar APK de release assinado com chave institucional, testar atualização, desinstalação e permissões. APK de depuração não é a versão para distribuição institucional.

## Como compilar em um PC Windows preparado

1. Instalar **Android Studio** com Android SDK API 35 e Java 17 (Android Studio fornece runtime compatível).
2. Abrir a pasta raiz `sentinela_mobile_android_v0_1` no Android Studio.
3. Instalar/selecionar Gradle 8.9 se o IDE solicitar (o projeto não inclui Gradle Wrapper JAR). A sincronização Gradle exige internet para baixar as dependências na primeira vez.
4. Em **Build > Build Bundle(s) / APK(s) > Build APK(s)**, gerar a versão de teste.
5. O arquivo esperado será `app/build/outputs/apk/debug/app-debug.apk`.
6. Instalar o APK apenas em aparelho institucional autorizado para testes sem dados reais.

### Primeiro roteiro de teste

1. Abrir app, cadastrar administrador com nome, matrícula e senha forte.
2. Em **Usuários**, cadastrar operador e agente, depois coletar assinatura cadastrada do primeiro agente.
3. Com o operador, abrir uma ocorrência. Usar “A caminho” e “Iniciar atendimento”.
4. Preencher BA, adicionar foto, digitar matrícula do primeiro agente e confirmar senha para recuperar assinatura. Coletar assinatura do responsável.
5. Salvar BA e concluir. Conferir PDF e ZIP.
6. **Não marcar sincronização como validada** sem um gateway disponível e uma cópia confirmada no servidor.

## Estrutura de arquivamento pretendida

```text
\\servidor02\Comp\SENTINELA\
  2026\
    11 - NOVEMBRO\
      OCORRENCIAS\
        2026-ABCD-0001 - Rua das Flores, 150\
          BA_2026-ABCD-0001.pdf
          FOTO_01.jpg
          FOTO_02.jpg
          manifest.json
          PACOTE_2026-ABCD-0001.zip
      VISTORIAS\
      APOIOS OPERACIONAIS\
      INTERDIÇÕES\
```

## Avisos técnicos e privacidade

- O sistema é um protótipo e não substitui procedimentos oficiais, arquivamento institucional ou sistemas ativos.
- O diretório de dados local do Android pode ser apagado ao desinstalar; exporte os dados antes de qualquer limpeza ou reinstalação.
- Não enviar dados pessoais reais ao gateway de teste ou serviços públicos. Use ambiente restrito com VPN, HTTPS, perfis autorizados e acordo institucional.
- Não expor `\\servidor02` ou o gateway diretamente na internet.

## Testes disponíveis nesta entrega

Os testes em `tests/test_gateway.py` validam regras básicas de arquivamento, autenticação do gateway e repetição idempotente. Executar: `python -m unittest discover -s tests -v`. Não substituem testes Android.

## Compilação automatizada opcional

Foi incluído `.github/workflows/build-apk.yml`. Se o código for colocado em um repositório GitHub privado autorizado, a ação **Compilar APK SENTINELA (teste)** pode instalar o SDK e gerar `app-debug.apk` em um servidor de build. Nenhuma ação foi executada aqui, e o GitHub não é necessário para o funcionamento do aplicativo. Não inclua dados reais, segredos ou chaves de assinatura no repositório.
